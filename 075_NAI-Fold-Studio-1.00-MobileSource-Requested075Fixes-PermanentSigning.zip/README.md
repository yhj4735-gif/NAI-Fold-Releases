# NAI Fold Studio v1.00 Auto Build

## 1.00 추가 — 전체 설정 파일 내보내기 / 가져오기
Settings & Tools → Tools에서 사용할 수 있습니다.

설정 파일에 포함:
- 현재 긍정/부정 프롬프트
- 캐릭터와 V5 위치/구도 설정
- 프롬프트 프리셋 / 캐릭터 프리셋
- 와일드카드
- Lorebook/캐릭터 설정집/세계관/스타일 항목
- 이미지 생성 설정과 기타 앱 설정

의도적으로 제외:
- NovelAI Persistent API Token
- 생성 이미지와 Gallery/History
- 현재 Comic Edit 이미지/오버레이 작업

PC에서 내보낸 JSON 설정 파일을 Fold에서 가져오거나 반대로 사용해 수동 동기화할 수 있습니다.
Tauri 앱에서는 시스템 파일 저장/선택창을 사용하고, 단독 HTML에서는 브라우저 다운로드/파일 선택 방식으로 동작합니다.


## 1.00 추가 기능 — 프리셋 저장
- 프롬프트 프리셋: 긍정 프롬프트 블록(이름/순서/내용) + 부정 프롬프트 저장/불러오기/덮어쓰기/삭제
- 캐릭터 프리셋: 이름/타입/캐릭터 프롬프트/네거티브 저장, 프리셋에서 새 캐릭터 추가
- 캐릭터 위치는 장면별 정보라 프리셋에 포함하지 않음
- 프리셋은 각 기기의 앱 로컬 저장소에 저장됨


**개발도구를 사용자 PC에 설치하지 않고 GitHub Actions가 Windows 설치 EXE와 Android/Fold APK를 대신 만드는 버전입니다.**

자세한 최초 설정은 [`★_자동빌드_사용법.md`](./★_자동빌드_사용법.md)를 보세요.

자동 산출물:
- `NAI-Fold-Studio-Windows-Setup.exe`
- `NAI-Fold-Studio-Android-Fold.apk`

GitHub Actions는 Tauri Windows NSIS installer와 Android debug APK를 빌드합니다.
Android APK는 개인 sideload 테스트용 고정 debug 키로 서명되어 후속 자동 빌드 APK를 기존 앱 위에 업데이트 설치할 수 있습니다.

046부터는 `build-auto-latest-release-updatefix-v8-stable-signing-icon.yml`을
`.github/workflows/build.yml`로 사용하세요. 이 워크플로는 Android 프로젝트가
생성한 임시 키를 `ci/android-debug.keystore`로 교체하고, 완성 APK의 실제 인증서가
고정 키와 같은지 `apksigner`로 검증합니다. 검증이 다르면 릴리스를 만들지 않습니다.
046은 새 서명 기준점이므로 기존 045를 제거한 뒤 한 번 새로 설치해야 하며,
047 이후에는 같은 패키지 위에 업데이트 설치할 수 있습니다.
이 워크플로를 저장소에 한 번 설치한 뒤에는 기존 방식대로 새 번호의 소스 ZIP만
저장소 최상위에 추가하면 됩니다. 각 후속 ZIP의 Android versionCode는 직전 버전보다
커야 하며, 워크플로는 046 이상부터 Android 허용 상한까지 자동으로 받아들입니다.

기능 코드 자체는 v1.00 Local Native 기반이며 NovelAI V5 이미지 생성 연결을 포함합니다.
