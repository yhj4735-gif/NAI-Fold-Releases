(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  root.BookmarkController038 = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  const THEMES = new Set(['white', 'dark', 'nai', 'spring', 'summer', 'autumn', 'winter', 'cherry', 'mountain', 'sea']);

  function initial(theme) {
    return { open: false, lockedPage: null, theme: THEMES.has(theme) ? theme : 'spring' };
  }

  function reduce(current, action) {
    const state = { ...current };
    switch (action.type) {
      case 'OPEN':
        state.open = true;
        state.lockedPage = action.activePage || null;
        return { state, allowed: true };
      case 'CLOSE':
        state.open = false;
        state.lockedPage = null;
        return { state, allowed: true };
      case 'TOGGLE':
        return reduce(state, { type: state.open ? 'CLOSE' : 'OPEN', activePage: action.activePage });
      case 'NAVIGATE':
        if (state.lockedPage) {
          return { state, allowed: false, message: '책갈피를 먼저 해제하세요.' };
        }
        return { state, allowed: true };
      case 'CLOSE_PAGE':
        // Lock only the four right-side navigation tabs. Modal and page close
        // controls must remain usable while the bookmark is open.
        return { state, allowed: true };
      case 'THEME':
        if (THEMES.has(action.theme)) state.theme = action.theme;
        return { state, allowed: true };
      default:
        return { state, allowed: true };
    }
  }

  function gesture(startY, endY, threshold) {
    const limit = Number.isFinite(threshold) ? threshold : 18;
    const delta = Number(endY) - Number(startY);
    if (delta >= limit) return 'OPEN';
    if (delta <= -limit) return 'CLOSE';
    return 'NONE';
  }

  return { initial, reduce, gesture, themes: [...THEMES] };
});
