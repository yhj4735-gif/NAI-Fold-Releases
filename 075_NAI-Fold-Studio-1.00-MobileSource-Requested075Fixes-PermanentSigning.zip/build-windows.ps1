$ErrorActionPreference="Stop"
npm install
npm run build:pc
Write-Host "Done. Check src-tauri\target\release\bundle\" -ForegroundColor Green
