$ErrorActionPreference="Stop"
$androidHome = Join-Path $env:USERPROFILE ".android"
New-Item -ItemType Directory -Force -Path $androidHome | Out-Null
Copy-Item "ci\android-debug.keystore" (Join-Path $androidHome "debug.keystore") -Force
npm install
if (-not (Test-Path "src-tauri\gen\android")) { npm run android:init }
python ci\sync_android_launcher_icon.py
Copy-Item "ci\android-debug.keystore" "src-tauri\gen\android\app\debug.keystore" -Force
Get-ChildItem "src-tauri\gen\android" -Filter "debug.keystore" -Recurse | ForEach-Object {
  Copy-Item "ci\android-debug.keystore" $_.FullName -Force
}
npm run build:android
Write-Host "046 baseline: com.naifold.studio / fixed ci/android-debug.keystore / versionCode 2099000046" -ForegroundColor Green
