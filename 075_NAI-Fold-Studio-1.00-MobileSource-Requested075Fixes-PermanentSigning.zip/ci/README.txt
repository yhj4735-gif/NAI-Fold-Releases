android-debug.keystore
- GitHub Actions에서 만드는 개인 테스트/사이드로드 APK의 서명을 매 빌드 동일하게 유지하기 위한 DEBUG 전용 키입니다.
- 비밀번호/alias는 Android 표준 debug 값(android/androiddebugkey)을 사용합니다.
- 이 키로 만든 APK는 같은 앱 위에 업데이트 설치가 가능합니다.
- Google Play 또는 공개 정식 배포용 서명키로 절대 사용하지 마세요.
- 정식 배포 단계에서는 별도의 비공개 release keystore + GitHub Secrets로 교체하세요.
- 046부터 워크플로가 HOME 키뿐 아니라 Tauri 생성 프로젝트의 app/debug.keystore도 이 파일로 덮어씁니다.
- 완성 APK는 apksigner로 이 키의 SHA-256 인증서와 일치하는지 확인하며, 불일치 시 빌드가 실패합니다.

054 permanent update-signing guard
- Do not replace ci/android-debug.keystore in future source versions.
- Pinned keystore SHA-256: d98486c90903842258548b7a36dd23ad0aeca42c28ba8c64200bba408b1afa1a
- Pinned certificate SHA-256: 18:6E:5C:13:2F:7C:44:0B:DB:0C:D9:6A:28:54:08:90:12:CF:BC:EC:DD:EE:48:3D:F4:A5:9B:C9:6D:1E:1F:B9
- Every Android build must fail if either fingerprint changes.
- Future APKs can update over installed builds only when package id remains com.naifold.studio and versionCode increases.

