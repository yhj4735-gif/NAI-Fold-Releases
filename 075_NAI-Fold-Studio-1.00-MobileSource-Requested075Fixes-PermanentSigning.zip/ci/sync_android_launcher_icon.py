#!/usr/bin/env python3
"""Replace every generated Android launcher bitmap with the 047 book/pen symbol."""

from pathlib import Path
from PIL import Image, ImageDraw, ImageOps

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "frontend" / "assets034" / "nai-fold-symbol-047-white.png"
RES = ROOT / "src-tauri" / "gen" / "android" / "app" / "src" / "main" / "res"
SIZES = {"mdpi": 48, "hdpi": 72, "xhdpi": 96, "xxhdpi": 144, "xxxhdpi": 192}


def fitted_symbol(source: Image.Image, size: int, coverage: float) -> Image.Image:
    alpha = source.getchannel("A")
    bbox = alpha.getbbox()
    if not bbox:
        raise RuntimeError("Launcher source has no visible pixels")
    cropped = source.crop(bbox)
    extent = max(1, round(size * coverage))
    fitted = ImageOps.contain(cropped, (extent, extent), Image.Resampling.LANCZOS)
    canvas = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    canvas.alpha_composite(fitted, ((size - fitted.width) // 2, (size - fitted.height) // 2))
    return canvas


def classic_icon(source: Image.Image, size: int, round_background: bool = False) -> Image.Image:
    canvas = Image.new("RGBA", (size, size), (0, 0, 0, 0) if round_background else "#071b5c")
    if round_background:
        ImageDraw.Draw(canvas).ellipse((0, 0, size - 1, size - 1), fill="#071b5c")
    symbol = fitted_symbol(source, size, 0.84)
    canvas.alpha_composite(symbol)
    return canvas


def main() -> None:
    if not RES.is_dir():
        raise RuntimeError(f"Generated Android resources not found: {RES}")
    source = Image.open(SOURCE).convert("RGBA")
    written = []
    for density, base in SIZES.items():
        folder = RES / f"mipmap-{density}"
        folder.mkdir(parents=True, exist_ok=True)
        classic = classic_icon(source, base)
        round_icon = classic_icon(source, base, round_background=True)
        foreground = fitted_symbol(source, base * 2, 0.62)
        classic_path = folder / "ic_launcher.png"
        classic.save(classic_path, optimize=True)
        written.append(classic_path)
        round_path = folder / "ic_launcher_round.png"
        round_icon.save(round_path, optimize=True)
        written.append(round_path)
        foreground_path = folder / "ic_launcher_foreground.png"
        foreground.save(foreground_path, optimize=True)
        written.append(foreground_path)

    foreground_xml = """<?xml version=\"1.0\" encoding=\"utf-8\"?>
<layer-list xmlns:android=\"http://schemas.android.com/apk/res/android\">
  <item android:drawable=\"@mipmap/ic_launcher_foreground\" />
</layer-list>
"""
    background_xml = """<?xml version=\"1.0\" encoding=\"utf-8\"?>
<shape xmlns:android=\"http://schemas.android.com/apk/res/android\" android:shape=\"rectangle\">
  <solid android:color=\"#071B5C\" />
</shape>
"""
    for folder_name in ("drawable", "drawable-v24"):
        folder = RES / folder_name
        folder.mkdir(parents=True, exist_ok=True)
        (folder / "ic_launcher_foreground.xml").write_text(foreground_xml, encoding="utf-8")
        written.append(folder / "ic_launcher_foreground.xml")
    drawable = RES / "drawable"
    (drawable / "ic_launcher_background.xml").write_text(background_xml, encoding="utf-8")
    written.append(drawable / "ic_launcher_background.xml")
    print(f"047 launcher icon synchronized: {len(written)} resources")


if __name__ == "__main__":
    main()
