#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]
fn main() { nai_fold_studio_lib::run(); }
