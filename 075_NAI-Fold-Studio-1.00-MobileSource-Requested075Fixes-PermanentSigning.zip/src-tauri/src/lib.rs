use serde_json::Value;
use std::{fs, path::PathBuf};
use std::io::{Cursor, Read, Write};
use tauri::{Manager, Emitter};
use std::time::Duration;
use base64::{engine::general_purpose::STANDARD as BASE64, Engine as _};
use sha2::{Digest, Sha256};

const IMAGE_API: &str = "https://image.novelai.net";
const CORE_API: &str = "https://api.novelai.net";
const TEXT_API: &str = "https://text.novelai.net";
const DANBOORU_API: &str = "https://danbooru.donmai.us";
const GELBOORU_API: &str = "https://gelbooru.com";
const OPENAI_API: &str = "https://api.openai.com";
const XAI_API: &str = "https://api.x.ai";
const GEMINI_API: &str = "https://generativelanguage.googleapis.com";

fn bearer(token: &str) -> String {
    if token.starts_with("Bearer ") {
        token.to_string()
    } else {
        format!("Bearer {}", token)
    }
}

async fn response_error(resp: reqwest::Response) -> String {
    let status = resp.status();
    let body = resp.text().await.unwrap_or_default();
    if let Ok(json) = serde_json::from_str::<Value>(&body) {
        if let Some(msg) = json.get("message").and_then(|v| v.as_str()) {
            return format!("NovelAI {}: {}", status.as_u16(), msg);
        }
        if let Some(msg) = json
            .get("error")
            .and_then(|v| v.get("message"))
            .and_then(|v| v.as_str())
        {
            return format!("NovelAI {}: {}", status.as_u16(), msg);
        }
    }
    if body.is_empty() {
        format!("NovelAI HTTP {}", status.as_u16())
    } else {
        format!("NovelAI HTTP {}: {}", status.as_u16(), body)
    }
}

fn token_file(app: &tauri::AppHandle) -> Result<PathBuf, String> {
    app.path()
        .app_data_dir()
        .map(|dir| dir.join("persistent_api_token"))
        .map_err(|e| format!("API 저장 위치 확인 실패: {e}"))
}

#[tauri::command]
fn save_persistent_token(app: tauri::AppHandle, token: String) -> Result<(), String> {
    let token = token.trim();
    if token.is_empty() {
        return Err("Persistent API Token이 비어 있습니다.".into());
    }
    let path = token_file(&app)?;
    if let Some(parent) = path.parent() {
        fs::create_dir_all(parent).map_err(|e| format!("API 저장 폴더 생성 실패: {e}"))?;
    }
    fs::write(&path, token.as_bytes()).map_err(|e| format!("API Token 저장 실패: {e}"))?;
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        fs::set_permissions(&path, fs::Permissions::from_mode(0o600))
            .map_err(|e| format!("API Token 권한 설정 실패: {e}"))?;
    }
    Ok(())
}

#[tauri::command]
fn load_persistent_token(app: tauri::AppHandle) -> Result<String, String> {
    let path = token_file(&app)?;
    if !path.exists() {
        return Ok(String::new());
    }
    fs::read_to_string(path)
        .map(|value| value.trim().to_string())
        .map_err(|e| format!("저장된 API Token 읽기 실패: {e}"))
}

#[tauri::command]
fn clear_persistent_token(app: tauri::AppHandle) -> Result<(), String> {
    let path = token_file(&app)?;
    if path.exists() {
        fs::remove_file(path).map_err(|e| format!("API Token 삭제 실패: {e}"))?;
    }
    Ok(())
}

fn provider_key_file(app: &tauri::AppHandle, provider: &str) -> Result<PathBuf, String> {
    let safe = match provider {
        "openai" => "openai_api_key",
        "gemini" => "gemini_api_key",
        "grok" => "xai_api_key",
        "gelbooru" => "gelbooru_api_key",
        _ => return Err("지원하지 않는 API 공급자입니다.".into()),
    };
    app.path().app_data_dir().map(|dir| dir.join(safe)).map_err(|e| format!("AI API 저장 위치 확인 실패: {e}"))
}

#[tauri::command]
fn save_provider_key(app: tauri::AppHandle, provider: String, key: String) -> Result<(), String> {
    let key = key.trim();
    if key.is_empty() { return Err("API Key가 비어 있습니다.".into()); }
    let path = provider_key_file(&app, provider.trim())?;
    if let Some(parent) = path.parent() { fs::create_dir_all(parent).map_err(|e| format!("AI API 저장 폴더 생성 실패: {e}"))?; }
    fs::write(&path, key.as_bytes()).map_err(|e| format!("AI API Key 저장 실패: {e}"))?;
    #[cfg(unix)] {
        use std::os::unix::fs::PermissionsExt;
        fs::set_permissions(&path, fs::Permissions::from_mode(0o600)).map_err(|e| format!("AI API Key 권한 설정 실패: {e}"))?;
    }
    Ok(())
}

#[tauri::command]
fn load_provider_key(app: tauri::AppHandle, provider: String) -> Result<String, String> {
    let path = provider_key_file(&app, provider.trim())?;
    if !path.exists() { return Ok(String::new()); }
    fs::read_to_string(path).map(|value| value.trim().to_string()).map_err(|e| format!("저장된 AI API Key 읽기 실패: {e}"))
}

#[tauri::command]
fn clear_provider_key(app: tauri::AppHandle, provider: String) -> Result<(), String> {
    let path = provider_key_file(&app, provider.trim())?;
    if path.exists() { fs::remove_file(path).map_err(|e| format!("AI API Key 삭제 실패: {e}"))?; }
    Ok(())
}

#[tauri::command]
async fn check_subscription(token: String) -> Result<Value, String> {
    let token = token.trim().to_string();
    if token.is_empty() {
        return Err("Persistent API Token이 비어 있습니다.".into());
    }
    let client = reqwest::Client::new();
    let resp = client
        .get(format!("{IMAGE_API}/user/subscription"))
        .header("Authorization", bearer(&token))
        .header("Accept", "application/json")
        .send()
        .await
        .map_err(|e| format!("NovelAI 연결 실패: {e}"))?;

    if !resp.status().is_success() {
        return Err(response_error(resp).await);
    }
    resp.json::<Value>()
        .await
        .map_err(|e| format!("구독 응답 해석 실패: {e}"))
}

#[tauri::command]
async fn generate_image(token: String, payload: Value) -> Result<Value, String> {
    let token = token.trim().to_string();
    if token.is_empty() {
        return Err("Persistent API Token이 비어 있습니다.".into());
    }
    let client = reqwest::Client::new();
    let resp = client
        .post(format!("{IMAGE_API}/ai/generate-image"))
        .header("Authorization", bearer(&token))
        .header("Accept", "application/json")
        .header("Content-Type", "application/json")
        .json(&payload)
        .send()
        .await
        .map_err(|e| format!("이미지 생성 요청 실패: {e}"))?;

    if !resp.status().is_success() {
        return Err(response_error(resp).await);
    }
    resp.json::<Value>()
        .await
        .map_err(|e| format!("이미지 응답 해석 실패: {e}"))
}

fn sniff_image_mime(bytes: &[u8]) -> Option<&'static str> {
    if bytes.starts_with(b"\x89PNG\r\n\x1a\n") { return Some("image/png"); }
    if bytes.starts_with(&[0xFF, 0xD8, 0xFF]) { return Some("image/jpeg"); }
    if bytes.len() >= 12 && &bytes[0..4] == b"RIFF" && &bytes[8..12] == b"WEBP" { return Some("image/webp"); }
    if bytes.starts_with(b"GIF87a") || bytes.starts_with(b"GIF89a") { return Some("image/gif"); }
    None
}

fn extract_upscale_image(bytes: &[u8]) -> Result<(Vec<u8>, &'static str), String> {
    if let Some(mime) = sniff_image_mime(bytes) {
        return Ok((bytes.to_vec(), mime));
    }
    if bytes.starts_with(b"PK\x03\x04") || bytes.starts_with(b"PK\x05\x06") || bytes.starts_with(b"PK\x07\x08") {
        let cursor = Cursor::new(bytes.to_vec());
        let mut archive = zip::ZipArchive::new(cursor).map_err(|e| format!("업스케일 ZIP 열기 실패: {e}"))?;
        for index in 0..archive.len() {
            let mut file = archive.by_index(index).map_err(|e| format!("업스케일 ZIP 항목 읽기 실패: {e}"))?;
            if file.is_dir() { continue; }
            let mut out = Vec::new();
            file.read_to_end(&mut out).map_err(|e| format!("업스케일 ZIP 이미지 추출 실패: {e}"))?;
            if let Some(mime) = sniff_image_mime(&out) {
                return Ok((out, mime));
            }
        }
        return Err("업스케일 ZIP 안에서 PNG/JPEG/WebP 이미지를 찾지 못했습니다.".into());
    }
    Err("NovelAI 업스케일 응답이 이미지 또는 ZIP 형식이 아닙니다.".into())
}

#[tauri::command]
async fn upscale_image(token: String, image: String, width: u32, height: u32, scale: u32) -> Result<Value, String> {
    let token = token.trim().to_string();
    if token.is_empty() {
        return Err("Persistent API Token이 비어 있습니다.".into());
    }
    if image.trim().is_empty() {
        return Err("업스케일할 이미지가 없습니다.".into());
    }
    if width == 0 || height == 0 {
        return Err("업스케일할 이미지의 원본 크기를 확인할 수 없습니다.".into());
    }
    if !matches!(scale, 2 | 4) {
        return Err("업스케일 배율은 2× 또는 4×만 사용할 수 있습니다.".into());
    }
    let client = reqwest::Client::builder()
        .timeout(Duration::from_secs(180))
        .build()
        .map_err(|e| format!("업스케일 클라이언트 준비 실패: {e}"))?;
    let resp = client
        .post(format!("{CORE_API}/ai/upscale"))
        .header("Authorization", bearer(&token))
        .header("Accept", "application/zip, application/x-zip-compressed, image/png, image/jpeg, image/webp, application/octet-stream")
        .header("Content-Type", "application/json")
        .json(&serde_json::json!({"image": image, "width": width, "height": height, "scale": scale}))
        .send()
        .await
        .map_err(|e| format!("NovelAI 업스케일 연결 실패: {e}"))?;
    if !resp.status().is_success() {
        return Err(response_error(resp).await);
    }
    let content_type = resp.headers().get(reqwest::header::CONTENT_TYPE)
        .and_then(|v| v.to_str().ok()).unwrap_or("").to_ascii_lowercase();
    if content_type.contains("json") {
        let json = resp.json::<Value>().await.map_err(|e| format!("업스케일 JSON 응답 해석 실패: {e}"))?;
        if json.get("images").and_then(|v| v.as_array()).map(|v| !v.is_empty()).unwrap_or(false) {
            return Ok(json);
        }
        return Err("NovelAI 업스케일 JSON 응답에 이미지가 없습니다.".into());
    }
    let bytes = resp.bytes().await.map_err(|e| format!("업스케일 응답 읽기 실패: {e}"))?;
    let (image_bytes, mime) = extract_upscale_image(&bytes)?;
    Ok(serde_json::json!({"images":[{"image":BASE64.encode(image_bytes),"mime":mime}]}))
}

#[tauri::command]
async fn fetch_text_models(token: String) -> Result<Value, String> {
    let token = token.trim().to_string();
    if token.is_empty() {
        return Err("Persistent API Token이 비어 있습니다.".into());
    }
    let client = reqwest::Client::new();
    let resp = client
        .get(format!("{TEXT_API}/oa/v1/models"))
        .header("Authorization", bearer(&token))
        .header("Accept", "application/json")
        .send()
        .await
        .map_err(|e| format!("NovelAI Text 모델 목록 연결 실패: {e}"))?;
    if !resp.status().is_success() {
        return Err(response_error(resp).await);
    }
    resp.json::<Value>()
        .await
        .map_err(|e| format!("NovelAI Text 모델 목록 해석 실패: {e}"))
}

fn string_from_text_node(value: &Value) -> Option<String> {
    match value {
        Value::String(text) => {
            let text = text.trim();
            (!text.is_empty()).then(|| text.to_string())
        }
        Value::Array(items) => {
            let parts: Vec<String> = items.iter().filter_map(string_from_text_node).collect();
            (!parts.is_empty()).then(|| parts.join(""))
        }
        Value::Object(map) => {
            // OpenAI-compatible APIs may return either a plain string or an array/object
            // of text blocks. Prefer fields that can actually contain generated prose.
            for key in ["text", "content", "value", "output_text", "parsedContent", "parsedReasoning", "reasoning_content"] {
                if let Some(found) = map.get(key).and_then(string_from_text_node) {
                    return Some(found);
                }
            }
            None
        }
        _ => None,
    }
}

fn extract_choice_text(choice: &Value) -> Option<String> {
    let direct_paths = [
        choice.get("text"),
        choice.get("parsedContent"),
        choice.pointer("/message/content"),
        choice.pointer("/message/parsedContent"),
        choice.pointer("/delta/content"),
        choice.get("content"),
        choice.get("output_text"),
    ];
    for candidate in direct_paths.into_iter().flatten() {
        if let Some(text) = string_from_text_node(candidate) {
            if !text.trim().is_empty() {
                return Some(text);
            }
        }
    }
    None
}

fn extract_generated_text(value: &Value) -> Option<String> {
    if let Some(choices) = value.get("choices").and_then(Value::as_array) {
        let parts: Vec<String> = choices.iter().filter_map(extract_choice_text).collect();
        if !parts.is_empty() {
            return Some(parts.join(""));
        }
    }

    for pointer in [
        "/_naifold_text", "/output_text", "/generated_text", "/completion",
        "/output", "/steps", "/response", "/result/text", "/data/output", "/data/text"
    ] {
        if let Some(candidate) = value.pointer(pointer) {
            if let Some(text) = string_from_text_node(candidate) {
                if !text.trim().is_empty() {
                    return Some(text);
                }
            }
        }
    }

    match value {
        Value::Array(items) => {
            // SSE chunks arrive as an array. Concatenate text from every chunk rather
            // than returning only the first token/chunk.
            let parts: Vec<String> = items.iter().filter_map(extract_generated_text).collect();
            (!parts.is_empty()).then(|| parts.join(""))
        }
        Value::String(text) => {
            let trimmed = text.trim();
            if trimmed.is_empty() {
                return None;
            }
            if trimmed.starts_with('{') || trimmed.starts_with('[') {
                if let Ok(nested) = serde_json::from_str::<Value>(trimmed) {
                    return extract_generated_text(&nested);
                }
            }
            Some(trimmed.to_string())
        }
        _ => None,
    }
}

fn body_preview(body: &str) -> String {
    let mut out = body.replace('\r', " ").replace('\n', " ").replace('\t', " ");
    if out.chars().count() > 700 {
        out = out.chars().take(700).collect::<String>() + "…";
    }
    out
}

fn parse_streamed_json_body(body: &str) -> Vec<Value> {
    let mut chunks = Vec::new();

    // Standard SSE: each generated chunk is carried in a `data:` line.
    for line in body.lines() {
        let line = line.trim();
        let Some(payload) = line.strip_prefix("data:").map(str::trim) else { continue };
        if payload.is_empty() || payload == "[DONE]" { continue; }
        if let Ok(json) = serde_json::from_str::<Value>(payload) {
            chunks.push(json);
        }
    }
    if !chunks.is_empty() { return chunks; }

    // NovelAI/OpenAI-compatible streaming responses may also arrive as
    // whitespace/newline-separated JSON objects without the SSE `data:` prefix.
    // Parse the JSON stream object-by-object instead of ever exposing the raw
    // payload (which can contain token_ids) as user-visible text.
    let stream = serde_json::Deserializer::from_str(body).into_iter::<Value>();
    for value in stream.flatten() { chunks.push(value); }
    chunks
}

async fn parse_novelai_text_response(
    resp: reqwest::Response,
    requested_model: &str,
    endpoint: &str,
) -> Result<Value, String> {
    if !resp.status().is_success() { return Err(response_error(resp).await); }
    let status = resp.status();
    let content_type = resp.headers().get(reqwest::header::CONTENT_TYPE)
        .and_then(|value| value.to_str().ok()).unwrap_or("(missing)").to_string();
    let body = resp.text().await.map_err(|e| format!("NovelAI Story 응답 읽기 실패: {e}"))?;

    let parsed: Value = match serde_json::from_str(&body) {
        Ok(value) => value,
        Err(_) => {
            let chunks = parse_streamed_json_body(&body);
            if chunks.is_empty() {
                // Never treat JSON-like/raw protocol payloads as generated prose.
                // That previously allowed token_ids arrays to leak into the chat UI.
                let trimmed = body.trim();
                if trimmed.starts_with('{') || trimmed.starts_with('[') || trimmed.contains("\"token_ids\"") {
                    return Err(format!(
                        "NovelAI 응답 스트림 해석 실패. endpoint={endpoint}, model={requested_model}, content-type={content_type}, 응답미리보기={}",
                        body_preview(&body)
                    ));
                }
                Value::String(trimmed.to_string())
            } else {
                Value::Array(chunks)
            }
        }
    };

    if let Some(text) = extract_generated_text(&parsed) {
        let text = text.trim().to_string();
        if !text.is_empty() {
            eprintln!(
                "[NovelAI Text 054] status={} endpoint={} content-type={} model={} chars={}",
                status.as_u16(), endpoint, content_type, requested_model, text.chars().count()
            );
            // Always return one canonical field to the frontend. Keep the raw server
            // object for diagnostics, but frontend parsing no longer depends on its shape.
            return Ok(serde_json::json!({
                "_naifold_text": text,
                "endpoint": endpoint,
                "model": requested_model,
                "raw": parsed
            }));
        }
    }

    let keys = parsed.as_object()
        .map(|map| map.keys().cloned().collect::<Vec<_>>().join(","))
        .unwrap_or_else(|| format!("{}", match &parsed { Value::Array(_) => "array", Value::String(_) => "string", _ => "other" }));
    eprintln!(
        "[NovelAI Text 054] empty generation status={} endpoint={} content-type={} model={} keys={} preview={}",
        status.as_u16(), endpoint, content_type, requested_model, keys, body_preview(&body)
    );
    Err(format!(
        "NovelAI 응답 파싱 실패: 생성 문장을 찾지 못했습니다. endpoint={endpoint}, model={requested_model}, 응답형태={keys}, 응답미리보기={}",
        body_preview(&body)
    ))
}

#[tauri::command]
async fn generate_story(token: String, prompt: String, model: String) -> Result<Value, String> {
    let token = token.trim().to_string();
    if token.is_empty() { return Err("Persistent API Token이 비어 있습니다.".into()); }
    let prompt = prompt.trim().to_string();
    if prompt.is_empty() { return Err("노벨스토리 요청 내용이 비어 있습니다.".into()); }
    let requested_model = model.trim().to_string();
    if requested_model.is_empty() { return Err("사용 가능한 NovelAI Text 모델을 먼저 선택해 주세요.".into()); }

    let client = reqwest::Client::builder()
        .connect_timeout(Duration::from_secs(20)).timeout(Duration::from_secs(120)).build()
        .map_err(|e| format!("NovelAI Story 클라이언트 준비 실패: {e}"))?;

    // NovelAI's current OpenAI-compatible text API accepts chat messages and model IDs
    // returned by /oa/v1/models. Use chat/completions first so GLM/Xialong models are
    // not accidentally sent to the legacy /ai/generate route.
    let chat_payload = serde_json::json!({
        "model": requested_model.clone(),
        "messages": [
            {"role": "system", "content": "Follow the user's requested writing task and return the requested text directly."},
            {"role": "user", "content": prompt.clone()}
        ],
        "max_tokens": 900,
        "temperature": 0.9,
        "top_p": 0.95,
        "stream": false
    });
    let chat_result = match client.post(format!("{TEXT_API}/oa/v1/chat/completions"))
        .header("Authorization", bearer(&token))
        .header("Accept", "application/json")
        .header("Content-Type", "application/json").json(&chat_payload).send().await
    {
        Ok(resp) => parse_novelai_text_response(resp, &requested_model, "chat/completions").await,
        Err(e) => Err(format!("NovelAI Chat Completion 연결 실패: {e}")),
    };
    if chat_result.is_ok() {
        return chat_result;
    }

    // Compatibility fallback for models/accounts that expose the classic OpenAI-style
    // text completion endpoint instead of chat completion.
    let completion_payload = serde_json::json!({
        "model": requested_model.clone(),
        "prompt": prompt.clone(),
        "max_tokens": 900,
        "temperature": 0.9,
        "top_p": 0.95,
        "stream": false
    });
    let completion_result = match client.post(format!("{TEXT_API}/oa/v1/completions"))
        .header("Authorization", bearer(&token))
        .header("Accept", "application/json")
        .header("Content-Type", "application/json").json(&completion_payload).send().await
    {
        Ok(resp) => parse_novelai_text_response(resp, &requested_model, "completions").await,
        Err(e) => Err(format!("NovelAI Text Completion 연결 실패: {e}")),
    };

    completion_result.map_err(|completion_error| format!(
        "Chat 시도: {} / Completion 시도: {}",
        chat_result.err().unwrap_or_else(|| "알 수 없는 오류".into()),
        completion_error
    ))
}


async fn external_response_error(provider: &str, resp: reqwest::Response) -> String {
    let status = resp.status();
    let body = resp.text().await.unwrap_or_default();
    if let Ok(json) = serde_json::from_str::<Value>(&body) {
        for pointer in ["/error/message", "/message", "/error/status", "/detail"] {
            if let Some(msg) = json.pointer(pointer).and_then(Value::as_str) {
                return format!("{} {}: {}", provider, status.as_u16(), msg);
            }
        }
    }
    let preview = body_preview(&body);
    if preview.is_empty() { format!("{} HTTP {}", provider, status.as_u16()) }
    else { format!("{} HTTP {}: {}", provider, status.as_u16(), preview) }
}

fn normalized_external_usage(provider: &str, json: &Value) -> Value {
    let lower = provider.to_ascii_lowercase();
    if lower.contains("gemini") {
        let usage = json.get("usageMetadata").or_else(|| json.get("usage_metadata")).or_else(|| json.get("usage"));
        let input = usage.and_then(|v| v.get("promptTokenCount").or_else(|| v.get("input_tokens")).or_else(|| v.get("inputTokens"))).and_then(Value::as_u64).unwrap_or(0);
        let output = usage.and_then(|v| v.get("candidatesTokenCount").or_else(|| v.get("output_tokens")).or_else(|| v.get("outputTokens"))).and_then(Value::as_u64).unwrap_or(0);
        let cached = usage.and_then(|v| v.get("cachedContentTokenCount").or_else(|| v.get("cached_tokens")).or_else(|| v.get("cachedTokens"))).and_then(Value::as_u64).unwrap_or(0);
        let thoughts = usage.and_then(|v| v.get("thoughtsTokenCount").or_else(|| v.get("thought_tokens")).or_else(|| v.get("thoughtTokens"))).and_then(Value::as_u64).unwrap_or(0);
        let total = usage.and_then(|v| v.get("totalTokenCount").or_else(|| v.get("total_tokens")).or_else(|| v.get("totalTokens"))).and_then(Value::as_u64).unwrap_or(input + output + thoughts);
        return serde_json::json!({"input_tokens":input,"output_tokens":output,"cached_tokens":cached,"thinking_tokens":thoughts,"total_tokens":total});
    }
    let usage = json.get("usage");
    let input = usage.and_then(|v| v.get("input_tokens").or_else(|| v.get("prompt_tokens"))).and_then(Value::as_u64).unwrap_or(0);
    let output = usage.and_then(|v| v.get("output_tokens").or_else(|| v.get("completion_tokens"))).and_then(Value::as_u64).unwrap_or(0);
    let cached = usage.and_then(|v| v.pointer("/input_tokens_details/cached_tokens").or_else(|| v.get("cached_tokens"))).and_then(Value::as_u64).unwrap_or(0);
    let reasoning = usage.and_then(|v| v.pointer("/output_tokens_details/reasoning_tokens").or_else(|| v.get("reasoning_tokens"))).and_then(Value::as_u64).unwrap_or(0);
    let total = usage.and_then(|v| v.get("total_tokens")).and_then(Value::as_u64).unwrap_or(input + output);
    serde_json::json!({"input_tokens":input,"output_tokens":output,"cached_tokens":cached,"thinking_tokens":reasoning,"total_tokens":total})
}

async fn parse_external_ai_response(provider: &str, model: &str, resp: reqwest::Response) -> Result<Value, String> {
    if !resp.status().is_success() { return Err(external_response_error(provider, resp).await); }
    let body = resp.text().await.map_err(|e| format!("{} 응답 읽기 실패: {e}", provider))?;
    let json: Value = serde_json::from_str(&body).map_err(|e| format!("{} 응답 JSON 해석 실패: {e}; {}", provider, body_preview(&body)))?;
    let text = extract_generated_text(&json).ok_or_else(|| format!("{} 응답 파싱 실패: 생성 문장을 찾지 못했습니다. model={}, 응답={}", provider, model, body_preview(&body)))?;
    let usage = normalized_external_usage(provider, &json);
    Ok(serde_json::json!({"_naifold_text": text.trim(), "provider": provider, "model": model, "usage": usage, "raw": json}))
}

#[tauri::command]
async fn generate_external_ai(provider: String, api_key: String, model: String, prompt: String) -> Result<Value, String> {
    let provider = provider.trim().to_ascii_lowercase();
    let api_key = api_key.trim().to_string();
    let model = model.trim().to_string();
    let prompt = prompt.trim().to_string();
    if api_key.is_empty() { return Err("AI API Key가 비어 있습니다.".into()); }
    if model.is_empty() { return Err("AI 모델명이 비어 있습니다.".into()); }
    if prompt.is_empty() { return Err("AI 요청 내용이 비어 있습니다.".into()); }
    let client = reqwest::Client::builder().connect_timeout(Duration::from_secs(20)).timeout(Duration::from_secs(150)).build().map_err(|e| format!("AI 클라이언트 준비 실패: {e}"))?;

    match provider.as_str() {
        "openai" => {
            let payload = serde_json::json!({"model": model.clone(), "input": prompt.clone()});
            let resp = client.post(format!("{OPENAI_API}/v1/responses"))
                .header("Authorization", bearer(&api_key)).header("Content-Type", "application/json").header("Accept", "application/json")
                .json(&payload).send().await.map_err(|e| format!("OpenAI 연결 실패: {e}"))?;
            parse_external_ai_response("OpenAI", &model, resp).await
        }
        "grok" => {
            let payload = serde_json::json!({"model": model.clone(), "input": prompt.clone()});
            let resp = client.post(format!("{XAI_API}/v1/responses"))
                .header("Authorization", bearer(&api_key)).header("Content-Type", "application/json").header("Accept", "application/json")
                .json(&payload).send().await.map_err(|e| format!("xAI 연결 실패: {e}"))?;
            parse_external_ai_response("xAI", &model, resp).await
        }
        "gemini" => {
            let payload = serde_json::json!({"model": model.clone(), "input": prompt.clone(), "store": false});
            let resp = client.post(format!("{GEMINI_API}/v1beta/interactions"))
                .header("x-goog-api-key", api_key).header("Content-Type", "application/json").header("Accept", "application/json")
                .json(&payload).send().await.map_err(|e| format!("Gemini 연결 실패: {e}"))?;
            parse_external_ai_response("Gemini", &model, resp).await
        }
        _ => Err("지원하지 않는 AI 공급자입니다.".into()),
    }
}

#[tauri::command]
async fn list_external_ai_models(provider: String, api_key: String) -> Result<Value, String> {
    let provider = provider.trim().to_ascii_lowercase();
    let api_key = api_key.trim().to_string();
    if api_key.is_empty() { return Err("AI API Key가 비어 있습니다.".into()); }
    let client = reqwest::Client::builder().connect_timeout(Duration::from_secs(20)).timeout(Duration::from_secs(60)).build().map_err(|e| format!("AI 모델 목록 클라이언트 준비 실패: {e}"))?;
    let response = match provider.as_str() {
        "openai" => client.get(format!("{OPENAI_API}/v1/models")).header("Authorization", bearer(&api_key)).header("Accept", "application/json").send().await.map_err(|e| format!("OpenAI 모델 목록 연결 실패: {e}"))?,
        "grok" => client.get(format!("{XAI_API}/v1/models")).header("Authorization", bearer(&api_key)).header("Accept", "application/json").send().await.map_err(|e| format!("xAI 모델 목록 연결 실패: {e}"))?,
        "gemini" => client.get(format!("{GEMINI_API}/v1beta/models")).header("x-goog-api-key", api_key).header("Accept", "application/json").send().await.map_err(|e| format!("Gemini 모델 목록 연결 실패: {e}"))?,
        _ => return Err("지원하지 않는 AI 공급자입니다.".into()),
    };
    if !response.status().is_success() { return Err(external_response_error(&provider, response).await); }
    let raw: Value = response.json().await.map_err(|e| format!("AI 모델 목록 응답 해석 실패: {e}"))?;
    let source = if provider == "gemini" { raw.get("models").and_then(Value::as_array) } else { raw.get("data").and_then(Value::as_array).or_else(|| raw.get("models").and_then(Value::as_array)) };
    let mut models = Vec::new();
    if let Some(items) = source {
        for item in items {
            let mut id = item.get("id").or_else(|| item.get("name")).and_then(Value::as_str).unwrap_or("").to_string();
            if provider == "gemini" { id = id.strip_prefix("models/").unwrap_or(&id).to_string(); }
            if id.is_empty() { continue; }
            if provider == "gemini" {
                if let Some(methods) = item.get("supportedGenerationMethods").and_then(Value::as_array) {
                    let usable = methods.iter().filter_map(Value::as_str).any(|m| matches!(m, "generateContent" | "streamGenerateContent" | "generateText" | "interact"));
                    if !usable { continue; }
                }
            }
            let pricing = item.get("pricing").or_else(|| item.get("price")).cloned().unwrap_or(Value::Null);
            let context = item.get("context_window").or_else(|| item.get("contextWindow")).or_else(|| item.get("inputTokenLimit")).cloned().unwrap_or(Value::Null);
            models.push(serde_json::json!({"id":id,"status":"available","context_window":context,"pricing":pricing}));
        }
    }
    models.sort_by(|a,b| a.get("id").and_then(Value::as_str).unwrap_or("").cmp(b.get("id").and_then(Value::as_str).unwrap_or("")));
    Ok(serde_json::json!({"provider":provider,"models":models}))
}

#[tauri::command]
async fn test_external_ai_model(provider: String, api_key: String, model: String) -> Result<Value, String> {
    generate_external_ai(provider, api_key, model, "Reply only with OK.".to_string()).await
}

#[tauri::command]
async fn fetch_danbooru_tags(query: String) -> Result<Value, String> {
    let query = query.trim();
    if query.len() < 2 {
        return Err("Danbooru 검색어를 두 글자 이상 입력해 주세요.".into());
    }
    if query.len() > 96 {
        return Err("Danbooru 검색어가 너무 깁니다.".into());
    }
    let client = reqwest::Client::builder()
        .user_agent("NAI-Fold-Studio/1.00 tag-autocomplete")
        .connect_timeout(Duration::from_secs(12))
        .timeout(Duration::from_secs(24))
        .build()
        .map_err(|e| format!("Danbooru 클라이언트 준비 실패: {e}"))?;
    let mut last_error = String::from("Danbooru 응답 없음");
    let mut tags = Value::Array(vec![]);
    for attempt in 1..=3 {
        let result = client.get(format!("{DANBOORU_API}/tags.json"))
            .query(&[("search[name_matches]", query), ("search[order]", "count"), ("limit", "100")])
            .header("Accept", "application/json").send().await;
        match result {
            Ok(resp) if resp.status().is_success() => match resp.json::<Value>().await {
                Ok(value) => { tags = value; break; }
                Err(e) => last_error = format!("응답 해석 실패: {e}"),
            },
            Ok(resp) => last_error = format!("HTTP {}", resp.status().as_u16()),
            Err(e) => last_error = format!("연결 실패({attempt}/3): {e}"),
        }
    }
    if !tags.is_array() || tags.as_array().is_some_and(Vec::is_empty) {
        return Err(format!("Danbooru 태그 {last_error}"));
    }
    if let Some(items) = tags.as_array_mut() {
        items.sort_by(|a, b| {
            let a_count = a.get("post_count").and_then(Value::as_i64).unwrap_or(0);
            let b_count = b.get("post_count").and_then(Value::as_i64).unwrap_or(0);
            b_count.cmp(&a_count)
        });
    }
    Ok(tags)
}


#[tauri::command]
async fn fetch_gelbooru_tags(query: String, user_id: Option<String>, api_key: Option<String>) -> Result<Value, String> {
    let query = query.trim();
    if query.len() < 2 {
        return Err("Gelbooru 검색어를 두 글자 이상 입력해 주세요.".into());
    }
    if query.len() > 96 {
        return Err("Gelbooru 검색어가 너무 깁니다.".into());
    }
    let pattern = if query.contains('%') || query.contains('_') {
        query.to_string()
    } else if query.contains('*') {
        query.replace('*', "%")
    } else {
        format!("{query}%")
    };
    let client = reqwest::Client::builder()
        .user_agent("NAI-Fold-Studio/1.00 tag-autocomplete")
        .connect_timeout(Duration::from_secs(12))
        .timeout(Duration::from_secs(24))
        .build()
        .map_err(|e| format!("Gelbooru 클라이언트 준비 실패: {e}"))?;
    let mut params: Vec<(&str, String)> = vec![
        ("page", "dapi".into()),
        ("s", "tag".into()),
        ("q", "index".into()),
        ("json", "1".into()),
        ("limit", "100".into()),
        ("orderby", "count".into()),
        ("order", "desc".into()),
        ("name_pattern", pattern.clone()),
    ];
    let user_id = user_id.unwrap_or_default().trim().to_string();
    let api_key = api_key.unwrap_or_default().trim().to_string();
    if !user_id.is_empty() && !api_key.is_empty() {
        params.push(("user_id", user_id));
        params.push(("api_key", api_key));
    }
    let resp = client
        .get(format!("{GELBOORU_API}/index.php"))
        .query(&params)
        .header("Accept", "application/json")
        .send().await
        .map_err(|e| format!("Gelbooru 연결 실패: {e}"))?;
    if !resp.status().is_success() {
        return Err(format!("Gelbooru HTTP {}", resp.status().as_u16()));
    }
    let raw: Value = resp.json().await.map_err(|e| format!("Gelbooru 응답 해석 실패: {e}"))?;
    let items: Vec<Value> = match raw {
        Value::Array(items) => items,
        Value::Object(mut obj) => obj.remove("tag").and_then(|v| v.as_array().cloned()).unwrap_or_default(),
        _ => Vec::new(),
    };
    let mut out = Vec::new();
    for item in items {
        let name = item.get("name").and_then(Value::as_str).unwrap_or("").trim();
        if name.is_empty() { continue; }
        let count = item.get("count").or_else(|| item.get("post_count")).and_then(|v| {
            v.as_i64().or_else(|| v.as_str().and_then(|x| x.parse::<i64>().ok()))
        }).unwrap_or(0);
        let category = item.get("type").or_else(|| item.get("category")).and_then(|v| {
            v.as_i64().or_else(|| v.as_str().and_then(|x| x.parse::<i64>().ok()))
        }).unwrap_or(0);
        out.push(serde_json::json!({
            "name": name,
            "post_count": count,
            "category": category,
            "source": "G"
        }));
    }
    out.sort_by(|a,b| b.get("post_count").and_then(Value::as_i64).unwrap_or(0).cmp(&a.get("post_count").and_then(Value::as_i64).unwrap_or(0)));
    Ok(Value::Array(out))
}

fn valid_github_repository(repository: &str) -> bool {
    let mut parts = repository.split('/');
    let owner = parts.next().unwrap_or("");
    let repo = parts.next().unwrap_or("");
    !owner.is_empty() && !repo.is_empty() && parts.next().is_none()
        && owner.chars().all(|c| c.is_ascii_alphanumeric() || matches!(c, '-' | '_' | '.'))
        && repo.chars().all(|c| c.is_ascii_alphanumeric() || matches!(c, '-' | '_' | '.'))
}

#[tauri::command]
async fn fetch_github_release_info(repository: String, tag: String) -> Result<Value, String> {
    let repository = repository.trim();
    let tag = tag.trim();
    if !valid_github_repository(repository) {
        return Err("업데이트 저장소 정보가 올바르지 않습니다.".into());
    }
    if tag.is_empty() || !tag.chars().all(|c| c.is_ascii_alphanumeric() || matches!(c, '-' | '_' | '.')) {
        return Err("업데이트 태그 정보가 올바르지 않습니다.".into());
    }
    let client = reqwest::Client::builder()
        .user_agent("NAI-Fold-Studio/1.00 updater")
        .connect_timeout(Duration::from_secs(12))
        .timeout(Duration::from_secs(30))
        .build()
        .map_err(|e| format!("GitHub 업데이트 확인 준비 실패: {e}"))?;
    let url = if tag.eq_ignore_ascii_case("latest") {
        format!("https://api.github.com/repos/{repository}/releases/latest")
    } else {
        format!("https://api.github.com/repos/{repository}/releases/tags/{tag}")
    };
    let resp = client.get(url)
        .header("Accept", "application/vnd.github+json")
        .header("X-GitHub-Api-Version", "2022-11-28")
        .send().await
        .map_err(|e| format!("GitHub 업데이트 확인 실패: {e}"))?;
    if !resp.status().is_success() {
        return Err(format!("GitHub Release HTTP {}", resp.status().as_u16()));
    }
    let mut release: Value = resp.json().await.map_err(|e| format!("GitHub Release 응답 해석 실패: {e}"))?;
    let manifest_url = release.get("assets").and_then(Value::as_array).and_then(|assets| {
        assets.iter().find(|asset| asset.get("name").and_then(Value::as_str) == Some("release-manifest.json"))
            .and_then(|asset| asset.get("browser_download_url").and_then(Value::as_str)).map(str::to_string)
    });
    if let Some(manifest_url) = manifest_url {
        if let Ok(resp) = client.get(manifest_url).header("Accept", "application/json").send().await {
            if resp.status().is_success() {
                if let Ok(manifest) = resp.json::<Value>().await {
                    if let Some(obj) = release.as_object_mut() { obj.insert("manifest".into(), manifest); }
                }
            }
        }
    }
    Ok(release)
}

#[tauri::command]
async fn fetch_github_releases(repository: String) -> Result<Value, String> {
    let repository = repository.trim();
    if !valid_github_repository(repository) {
        return Err("업데이트 저장소 정보가 올바르지 않습니다.".into());
    }
    let client = reqwest::Client::builder()
        .user_agent("NAI-Fold-Studio/1.00 updater")
        .connect_timeout(Duration::from_secs(12))
        .timeout(Duration::from_secs(30))
        .build()
        .map_err(|e| format!("GitHub 이전 버전 확인 준비 실패: {e}"))?;
    let url = format!("https://api.github.com/repos/{repository}/releases?per_page=30");
    let resp = client.get(url)
        .header("Accept", "application/vnd.github+json")
        .header("X-GitHub-Api-Version", "2022-11-28")
        .send().await
        .map_err(|e| format!("GitHub 이전 버전 확인 실패: {e}"))?;
    if !resp.status().is_success() {
        return Err(format!("GitHub Releases HTTP {}", resp.status().as_u16()));
    }
    resp.json::<Value>().await.map_err(|e| format!("GitHub Releases 응답 해석 실패: {e}"))
}

fn valid_release_asset_url075(url: &str) -> bool {
    url.starts_with("https://github.com/yhj4735-gif/NAI-Fold-Releases/releases/download/")
}

fn safe_update_filename075(name: &str) -> Result<String, String> {
    let name = name.trim();
    if name.is_empty() || name.len() > 160 || name.contains('/') || name.contains('\\') || name.contains("..") {
        return Err("업데이트 파일 이름이 올바르지 않습니다.".into());
    }
    if !(name.to_ascii_lowercase().ends_with(".apk") || name.to_ascii_lowercase().ends_with(".exe")) {
        return Err("지원하지 않는 업데이트 파일 형식입니다.".into());
    }
    Ok(name.to_string())
}

#[tauri::command]
async fn download_update_asset(app: tauri::AppHandle, url: String, file_name: String, sha256_url: Option<String>) -> Result<Value, String> {
    let url = url.trim().to_string();
    if !valid_release_asset_url075(&url) { return Err("업데이트 파일 주소가 공식 공개 Release 주소가 아닙니다.".into()); }
    let file_name = safe_update_filename075(&file_name)?;
    let client = reqwest::Client::builder()
        .user_agent("NAI-Fold-Studio/1.00 updater")
        .connect_timeout(Duration::from_secs(15))
        .timeout(Duration::from_secs(600))
        .build().map_err(|e| format!("업데이트 다운로드 준비 실패: {e}"))?;
    let mut expected_sha = String::new();
    if let Some(sha_url) = sha256_url.filter(|x| !x.trim().is_empty()) {
        if valid_release_asset_url075(sha_url.trim()) {
            if let Ok(resp) = client.get(sha_url.trim()).send().await {
                if resp.status().is_success() {
                    if let Ok(text) = resp.text().await {
                        let mut candidates: Vec<String> = Vec::new();
                        for line in text.lines() {
                            let hashes: Vec<&str> = line.split_whitespace()
                                .filter(|x| x.len() == 64 && x.chars().all(|c| c.is_ascii_hexdigit()))
                                .collect();
                            if line.contains(&file_name) {
                                if let Some(candidate) = hashes.first() { expected_sha = candidate.to_ascii_lowercase(); break; }
                            }
                            candidates.extend(hashes.into_iter().map(|x| x.to_ascii_lowercase()));
                        }
                        if expected_sha.is_empty() && candidates.len() == 1 { expected_sha = candidates[0].clone(); }
                    }
                }
            }
        }
    }
    let mut resp = client.get(&url).header("Accept", "application/octet-stream").send().await.map_err(|e| format!("업데이트 다운로드 연결 실패: {e}"))?;
    if !resp.status().is_success() { return Err(format!("업데이트 다운로드 HTTP {}", resp.status().as_u16())); }
    let content_type = resp.headers().get(reqwest::header::CONTENT_TYPE).and_then(|v| v.to_str().ok()).unwrap_or("").to_ascii_lowercase();
    if content_type.contains("text/html") || content_type.contains("application/json") { return Err(format!("업데이트 파일 대신 잘못된 응답을 받았습니다: {content_type}")); }
    let total = resp.content_length().unwrap_or(0);
    let folder = app.path().app_data_dir().map_err(|e| format!("업데이트 저장 위치 확인 실패: {e}"))?.join("updates");
    fs::create_dir_all(&folder).map_err(|e| format!("업데이트 저장 폴더 생성 실패: {e}"))?;
    let path = folder.join(&file_name);
    let mut file = fs::File::create(&path).map_err(|e| format!("업데이트 파일 생성 실패: {e}"))?;
    let mut downloaded: u64 = 0;
    let mut hasher = Sha256::new();
    while let Some(chunk) = resp.chunk().await.map_err(|e| format!("업데이트 다운로드 중 오류: {e}"))? {
        file.write_all(&chunk).map_err(|e| format!("업데이트 파일 저장 실패: {e}"))?;
        hasher.update(&chunk);
        downloaded += chunk.len() as u64;
        let percent = if total > 0 { (downloaded as f64 / total as f64 * 100.0).min(100.0) } else { 0.0 };
        let _ = app.emit("update-download-progress", serde_json::json!({"downloaded":downloaded,"total":total,"percent":percent}));
    }
    file.flush().map_err(|e| format!("업데이트 파일 저장 완료 처리 실패: {e}"))?;
    if downloaded == 0 { let _=fs::remove_file(&path); return Err("다운로드된 업데이트 파일이 비어 있습니다.".into()); }
    let actual_sha: String = hasher.finalize().iter().map(|b| format!("{b:02x}")).collect();
    if !expected_sha.is_empty() && actual_sha != expected_sha { let _=fs::remove_file(&path); return Err("업데이트 SHA256 검증에 실패했습니다.".into()); }
    #[cfg(target_os = "android")]
    {
        let bytes = fs::read(&path).map_err(|e| format!("APK 검증 실패: {e}"))?;
        if bytes.len() < 4 || &bytes[..2] != b"PK" { let _=fs::remove_file(&path); return Err("다운로드된 파일이 올바른 APK/ZIP 형식이 아닙니다.".into()); }
    }
    Ok(serde_json::json!({"path":path.to_string_lossy(),"bytes":downloaded,"sha256":actual_sha,"verified":!expected_sha.is_empty()}))
}

#[tauri::command]
fn install_downloaded_update(app: tauri::AppHandle, path: String) -> Result<(), String> {
    use tauri_plugin_opener::OpenerExt;
    let path = PathBuf::from(path.trim());
    if !path.exists() { return Err("다운로드한 업데이트 파일을 찾지 못했습니다.".into()); }
    let allowed_root = app.path().app_data_dir().map_err(|e| format!("업데이트 저장 위치 확인 실패: {e}"))?.join("updates");
    if !path.starts_with(&allowed_root) { return Err("앱 업데이트 폴더 밖의 파일은 열 수 없습니다.".into()); }
    let ext = path.extension().and_then(|x| x.to_str()).unwrap_or("").to_ascii_lowercase();
    if ext != "apk" && ext != "exe" { return Err("지원하지 않는 설치 파일 형식입니다.".into()); }
    app.opener().open_path(path.to_string_lossy().to_string(), None::<&str>).map_err(|e| format!("설치 파일 열기 실패: {e}"))
}

#[tauri::command]
fn open_external_url(app: tauri::AppHandle, url: String) -> Result<(), String> {
    use tauri_plugin_opener::OpenerExt;
    let url = url.trim();
    if !url.starts_with("https://github.com/") {
        return Err("업데이트 링크가 GitHub HTTPS 주소가 아닙니다.".into());
    }
    app.opener().open_url(url, None::<&str>).map_err(|e| format!("업데이트 링크 열기 실패: {e}"))
}

#[tauri::command]
fn open_help_url(app: tauri::AppHandle, url: String) -> Result<(), String> {
    use tauri_plugin_opener::OpenerExt;
    let url = url.trim();
    let allowed = [
        "https://gelbooru.com/",
        "https://platform.openai.com/",
        "https://aistudio.google.com/",
        "https://console.x.ai/",
    ];
    if !allowed.iter().any(|prefix| url.starts_with(prefix)) {
        return Err("허용되지 않은 API 도움말 링크입니다.".into());
    }
    app.opener().open_url(url, None::<&str>).map_err(|e| format!("API 도움말 링크 열기 실패: {e}"))
}

#[tauri::command]
fn save_comic_png(app: tauri::AppHandle, bytes: Vec<u8>, filename: String) -> Result<String, String> {
    if bytes.len() < 8 || &bytes[..8] != b"\x89PNG\r\n\x1a\n" {
        return Err("저장 데이터가 올바른 PNG가 아닙니다.".into());
    }
    let safe_name: String = filename
        .chars()
        .map(|c| if c.is_ascii_alphanumeric() || matches!(c, '-' | '_' | '.') { c } else { '_' })
        .collect();
    let safe_name = if safe_name.to_ascii_lowercase().ends_with(".png") {
        safe_name
    } else {
        format!("{safe_name}.png")
    };

    #[cfg(target_os = "android")]
    let folder = app
        .path()
        .app_data_dir()
        .map_err(|e| format!("앱 저장 폴더 확인 실패: {e}"))?
        .join("Pictures/NAI-Fold-Studio");

    #[cfg(not(target_os = "android"))]
    let folder = {
        let base = std::env::var_os("USERPROFILE")
            .or_else(|| std::env::var_os("HOME"))
            .map(PathBuf::from)
            .ok_or_else(|| "사용자 저장 폴더를 찾지 못했습니다.".to_string())?;
        let pictures = base.join("Pictures");
        if pictures.exists() { pictures.join("NAI-Fold-Studio") } else { base.join("Downloads").join("NAI-Fold-Studio") }
    };

    fs::create_dir_all(&folder).map_err(|e| format!("저장 폴더 생성 실패: {e}"))?;
    let path = folder.join(safe_name);
    fs::write(&path, bytes).map_err(|e| format!("이미지 파일 저장 실패: {e}"))?;
    Ok(path.to_string_lossy().into_owned())
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .plugin(tauri_plugin_dialog::init())
        .plugin(tauri_plugin_fs::init())
        .plugin(tauri_plugin_opener::init())
        .invoke_handler(tauri::generate_handler![
            check_subscription,
            generate_image,
            upscale_image,
            fetch_text_models,
            generate_story,
            fetch_danbooru_tags,
            fetch_gelbooru_tags,
            fetch_github_release_info,
            fetch_github_releases,
            download_update_asset,
            install_downloaded_update,
            open_external_url,
            open_help_url,
            save_persistent_token,
            load_persistent_token,
            clear_persistent_token,
            save_provider_key,
            load_provider_key,
            clear_provider_key,
            generate_external_ai,
            list_external_ai_models,
            test_external_ai_model,
            save_comic_png
        ])
        .run(tauri::generate_context!())
        .expect("error while running NAI Fold Studio");
}
