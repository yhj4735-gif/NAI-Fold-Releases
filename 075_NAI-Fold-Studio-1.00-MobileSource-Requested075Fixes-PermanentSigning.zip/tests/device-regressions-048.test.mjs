import assert from 'node:assert/strict';
import fs from 'node:fs';

const html=fs.readFileSync(new URL('../frontend/index.html',import.meta.url),'utf8');
const tauri=JSON.parse(fs.readFileSync(new URL('../src-tauri/tauri.conf.json',import.meta.url),'utf8'));

assert.ok(tauri.bundle.android.versionCode>=2099000051);

assert.match(html,/--modal-z048/);
assert.match(html,/let modalLayer048=2600/);
assert.match(html,/body:has\(\.modal\.show:not\(#comicModal\.diary-comic-page\)\) \.page-bookmark038-hit\{pointer-events:none!important\}/);
assert.match(html,/\.panel\.open \[data-close\],#comicModal\.diary-comic-page \[data-modal-close\]/);
assert.match(html,/hideDiaryTarget\(target\)/);

assert.match(html,/grid-template-columns:minmax\(170px,\.72fr\) minmax\(0,1\.8fr\)!important/);
assert.match(html,/class="wildcard-main048"/);
assert.match(html,/class="wildcard-saved048"/);
assert.match(html,/max-width:480px/);

assert.match(html,/KO_QUERY_048/);
assert.match(html,/'검은 머리':'black_hair'/);
assert.match(html,/'엘소드':'elsword'/);
assert.match(html,/danbooruTagToKorean048/);
assert.match(html,/wc-result-ko048/);
assert.match(html,/id="editorTagSuggestions048"/);
assert.match(html,/runEditorTagSuggestions048/);

assert.match(html,/\.wc-preview\{[\s\S]*?color:#f7fff1!important/);
assert.match(html,/body \.topbar \.brand\{background:transparent!important/);
assert.match(html,/brandSymbol\.src='assets034\/nai-fold-symbol-047-white\.png'/);

console.log('device-regressions-048: modal stack, independent close, compact Korean tag UI, prompt suggestions and clear branding passed');
