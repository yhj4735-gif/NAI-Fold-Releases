import assert from 'node:assert/strict';
import fs from 'node:fs';

const html=fs.readFileSync(new URL('../frontend/index.html',import.meta.url),'utf8');

assert.match(html,/053 FOLD COMIC THREE-COLUMN FIX/);
assert.match(html,/--panel-safe-right053:calc\(var\(--rail-hit038\) \+ 2px\)/);
assert.match(html,/\.story-model-bar045\{grid-template-columns:minmax\(0,1fr\) auto!important/);
assert.match(html,/body\.ratio-10-9 #comicModal\.diary-comic-page \.comic-editor-layout/);
assert.match(html,/grid-template-columns:minmax\(300px,40%\) minmax\(300px,1fr\) 30px!important/);
assert.match(html,/body\.ratio-4-3 #comicModal \.comic-canvas-wrap/);
assert.match(html,/body\.diary-landscape #comicModal \.comic-controls-scroll/);
assert.match(html,/#comicModal \.comic-action-rail052 \.btn\{[\s\S]*?width:30px!important[\s\S]*?height:48px!important/);
assert.match(html,/body:not\(\.ratio-10-9\):not\(\.ratio-4-3\) #comicModal \.comic-editor-layout/);

console.log('device-regressions-053: Fold three-column comic layout, compact action rail and reduced content safe-zone passed');
