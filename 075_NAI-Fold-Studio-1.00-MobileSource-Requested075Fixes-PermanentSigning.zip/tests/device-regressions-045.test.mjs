import assert from 'node:assert/strict';
import fs from 'node:fs';

const html=fs.readFileSync(new URL('../frontend/index.html',import.meta.url),'utf8');
const rust=fs.readFileSync(new URL('../src-tauri/src/lib.rs',import.meta.url),'utf8');
const tauri=JSON.parse(fs.readFileSync(new URL('../src-tauri/tauri.conf.json',import.meta.url),'utf8'));

assert.match(rust,/\.get\(format!\("\{TEXT_API\}\/oa\/v1\/models"\)\)/);
assert.match(rust,/\.post\(format!\("\{TEXT_API\}\/oa\/v1\/chat\/completions"\)\)/);
assert.doesNotMatch(rust,/TEXT_API\}\/ai\/generate/);
assert.doesNotMatch(rust,/for fallback in/);
assert.match(html,/id="storyModelSelect"/);
assert.match(html,/id="refreshStoryModelsBtn"/);
assert.match(html,/normalizeStoryModels045/);
assert.match(html,/state\.storyModels=models/);
assert.match(html,/model:selectedTextModel/);
assert.doesNotMatch(html,/model:'(?:xialong|glm-4-6|clio-v1)'/);
assert.match(rust,/save_persistent_token/);
assert.match(rust,/load_persistent_token/);
assert.match(rust,/clear_persistent_token/);
assert.match(html,/data-theme-surface="solid"/);
assert.match(html,/body\[data-theme-surface="solid"\] \.app-background038/);
assert.match(html,/\.brand-name\{[\s\S]*?filter:none!important/);
assert.match(html,/--rail-start045:24dvh/);
assert.match(html,/\.diary-tab\.is-current\{outline:0!important\}/);
assert.match(html,/\.page-bookmark038\{z-index:2050!important/);
assert.match(html,/\.page-bookmark038\[data-open="true"\] \.page-bookmark038-hit\{[\s\S]*?width:100%!important;[\s\S]*?height:100%!important/);
assert.match(html,/#panel-workspace \.workspace-column032\{padding-bottom:var\(--panel-safe-pad045\)!important/);
assert.match(html,/openMainPositionEditor045/);
assert.match(html,/className='main-position-layer045'/);
assert.equal(tauri.identifier,'com.naifold.studio');
assert.equal(tauri.version,'1.0.0');
assert.ok(tauri.bundle.android.versionCode>=2099000051);

console.log('device-regressions-045: live text models, OA chat, persistent API, thumb rail, bookmark hit area, prompt safe zone, solid themes and inline V5 placement passed');
