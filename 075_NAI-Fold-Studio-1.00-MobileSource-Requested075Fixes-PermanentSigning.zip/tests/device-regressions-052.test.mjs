import assert from 'node:assert/strict';
import fs from 'node:fs';

const html=fs.readFileSync(new URL('../frontend/index.html',import.meta.url),'utf8');
const config=JSON.parse(fs.readFileSync(new URL('../src-tauri/tauri.conf.json',import.meta.url),'utf8'));

assert.equal(config.identifier,'com.naifold.studio');
assert.equal(config.version,'1.0.0');
assert.ok(config.bundle.android.versionCode>=2099000053);

for(const id of ['overlayFontOut','overlayRotateOut','overlaySpacingOut','overlayIrregularOut','overlayWOut']){
  assert.match(html,new RegExp(`id="${id}" type="number"`));
}
assert.match(html,/bindComicNumber052\('overlayFontOut','overlayFontRange'\)/);
assert.match(html,/bindComicNumber052\('overlayWOut','overlayWRange'\)/);
assert.match(html,/class="comic-action-rail052"/);
assert.match(html,/class="compact-card comic-under-preview052"/);
assert.doesNotMatch(html,/<div class="section-head"><div class="section-title">오버레이 목록<\/div><span class="tag">drag<\/span>/);
assert.match(html,/data-overlay-drag051="\$\{item\.id\}">이동<\/button>/);
assert.match(html,/data-joystick-dx052="0" data-joystick-dy052="-1"/);
assert.match(html,/setTimeout\(\(\)=>\{if\(!hold\)return;hold\.repeat=setInterval/);
assert.match(html,/한 번 누르면 한 칸, 길게 누르면 누르는 동안 계속 부드럽게 이동합니다/);
assert.match(html,/\.top-meta-cluster\{width:min\(405px,100%\)!important/);
assert.match(html,/'보브컷':'bob_cut'/);
assert.match(html,/'팔짱':'crossed_arms'/);
assert.match(html,/'사무실':'office'/);
assert.match(html,/'카우보이샷':'cowboy_shot'/);
assert.match(html,/'영화조명':'cinematic_lighting'/);
assert.match(html,/cinematic_lighting:'영화 같은 조명'/);

console.log('device-regressions-052: numeric entry, directional hold joystick, compact action rail, preview overlay list, header width and expanded Korean tags passed');
