import fs from 'node:fs';
import assert from 'node:assert/strict';
const html=fs.readFileSync(new URL('../frontend/index.html',import.meta.url),'utf8');
const rust=fs.readFileSync(new URL('../src-tauri/src/lib.rs',import.meta.url),'utf8');
const conf=JSON.parse(fs.readFileSync(new URL('../src-tauri/tauri.conf.json',import.meta.url),'utf8'));
assert.equal(conf.version,'1.0.0');
assert.equal(conf.identifier,'com.naifold.studio');
assert.ok(conf.bundle.android.versionCode>=2099000069);

// Requested history header/layout and gallery entry point.
assert.match(html,/id="openHistoryGallery068"[^>]*>최근 이미지<\/button>/);
assert.match(html,/data-favorite-filter066="favorite"[^>]*>★<\/button>/);
assert.match(html,/id="historyGallery068"/);
assert.match(html,/function openHistoryGallery068\(\)/);
assert.match(html,/function renderHistoryGallery068\(\)/);
assert.match(html,/id="mainImageSaveBtn068"/);

// Generate button keeps a fixed box and swaps only spinner/label state.
assert.match(html,/class="gen-spinner068"/);
assert.match(html,/class="generate-label068">이미지생성<\/span>/);
assert.match(html,/생성 중/);
assert.match(html,/#generateBtn\.generating \.gen-spinner068/);

// Story actual chat box is enlarged.
assert.match(html,/#panel-ai \.chat-log\{height:clamp\(340px,48dvh,620px\)!important/);

// Comic close gets an extra leftward safety offset.
assert.match(html,/#comicModal \.comic-close067\{position:relative!important;right:10px!important;transform:translateX\(-8px\)!important/);

// Main V5 overlay no longer renders apply/cancel buttons.
assert.match(html,/toolbar\.innerHTML='<button type="button" data-main-position="reset">초기 배치<\/button><button type="button" data-main-position="ai">전부 AI<\/button>'/);
assert.doesNotMatch(html,/data-main-position="apply"/);
assert.doesNotMatch(html,/data-main-position="cancel"/);

// Korean reverse-search / translation cache requested for wildcard autocomplete.
assert.match(html,/tagTranslationCache068/);
assert.match(html,/KO_SEARCH_ALIASES068/);
assert.match(html,/empty_eyes:\['빈','동공'/);
assert.match(html,/silver_hair:\['은색','머리'/);
assert.match(html,/silver_hair:'은색 머리'/);
assert.match(html,/empty_eyes:'빈 동공'/);
assert.match(html,/function localKoreanTagCandidates068\(/);

// Upscale native command remains present; its request schema is validated by the current revision test.
assert.match(rust,/async fn upscale_image\(token: String, image: String/);

// Inpainting maps generation models to dedicated inpainting model ids.
assert.match(html,/nai-diffusion-5-full-inpainting/);
assert.match(html,/nai-diffusion-4-5-curated-inpainting/);
assert.match(html,/function prepareInpaintPayload068\(/);

console.log('device-regressions-068: requested-only history/gallery, save/loading, Story, Comic safety, V5 toggle, Korean wildcard search, upscale and inpaint fixes passed');
