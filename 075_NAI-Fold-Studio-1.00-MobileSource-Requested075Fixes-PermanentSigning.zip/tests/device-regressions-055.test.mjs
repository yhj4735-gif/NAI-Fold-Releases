import assert from 'node:assert/strict';
import fs from 'node:fs';
const html=fs.readFileSync(new URL('../frontend/index.html',import.meta.url),'utf8');
const rust=fs.readFileSync(new URL('../src-tauri/src/lib.rs',import.meta.url),'utf8');
const config=JSON.parse(fs.readFileSync(new URL('../src-tauri/tauri.conf.json',import.meta.url),'utf8'));
const build=fs.readFileSync(new URL('../build.yml',import.meta.url),'utf8');

assert.ok(config.bundle.android.versionCode>=2099000055);
assert.equal(config.identifier,'com.naifold.studio');
assert.match(build,/PINNED_KEYSTORE_SHA256="d98486c90903842258548b7a36dd23ad0aeca42c28ba8c64200bba408b1afa1a"/);
assert.match(build,/PINNED_CERT_SHA256="186e5c132f7c440bdb0cd96a2854089012cfbcecddee483df4a59bc96d1e1fb9"/i);

assert.match(html,/id="comicAddToggle055"/);
assert.match(html,/id="comicAddMenu055"/);
assert.doesNotMatch(html,/id="deleteOverlayBtn"/);
assert.match(html,/data-overlay-delete055/);
assert.match(html,/requestDeleteConfirm\(overlayDeleteLabel055/);
assert.match(html,/id="overlayText" aria-label="선택 오버레이 텍스트"/);
assert.match(html,/id="comicFocusJoystick055"/);
assert.match(html,/id="comicFocusMoveBtn055"/);
assert.doesNotMatch(html,/data-comic-nudge037=/);
assert.match(html,/grid-template-columns:minmax\((?:250px,31%|220px,27%|196px,25%)\) minmax\(0,1fr\)/);
assert.match(html,/--panel-safe-right055:(?:calc\(var\(--rail-hit038\) - 8px\)|24px)/);

for(const provider of ['novelai','openai','gemini','grok']) assert.match(html,new RegExp(`data-story-provider055="${provider}"`));
assert.match(html,/id="apiModal"/);
assert.match(html,/class="modal-card api-unified058"/);
assert.match(html,/id="openAiKey055"/);
assert.match(html,/id="geminiKey055"/);
assert.match(html,/id="grokKey055"/);
assert.match(rust,/async fn generate_external_ai/);
assert.match(rust,/https:\/\/api\.openai\.com/);
assert.match(rust,/https:\/\/api\.x\.ai/);
assert.match(rust,/https:\/\/generativelanguage\.googleapis\.com/);
assert.match(rust,/\/v1\/responses/);
assert.match(rust,/\/v1beta\/interactions/);
assert.match(rust,/save_provider_key/);
assert.match(rust,/load_provider_key/);
console.log('device-regressions-055: Comic layout/joystick, Story providers, and permanent signing assertions passed');
