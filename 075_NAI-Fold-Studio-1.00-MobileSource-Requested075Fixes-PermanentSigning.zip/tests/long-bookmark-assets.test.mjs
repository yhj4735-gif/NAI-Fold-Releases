import assert from 'node:assert/strict';
import fs from 'node:fs';

const themes = ['white','dark','nai','spring','summer','autumn','winter','cherry','mountain','sea'];
const expectedSha256 = {
  white: '92fb6c3868ac4b75f5a06ac5496e672f41da2609d654c045428bb89c4df7f955',
  dark: 'fe0af294050fa8dee8f77f3593d7c1404ca75d8b90a0a85ff7266573638a05dd',
  nai: 'f807f29ed63b4aee50db675abb57eb04446c31a1e6cc663aa1585bdb2a4ae3e5',
  spring: '1145f9efb29f419e51331d56ca881af6cebd6b9fa2a62dc18a0c868d12321bb5',
  summer: '55c14d03e1c4c1800b259d9df30000f3683ed90d8444716cb887fc33226a37f4',
  autumn: '556aafb763df5c2b848f715532cb795b323e143459e56089ee0250e9d6166fc7',
  winter: '1ad4d620994b7dd41c8e78f4a58b6b29f0ac5dc9bc94629f761132155502d673',
  cherry: '760b13842904db249cc7c461a10ca8485bea2f0f07d466f178f43bc1a1612bbf',
  mountain: 'c83acf960c5425164a8a03f88382820e3da32d2e68f9d3f1d827987230c73462',
  sea: '3887910916ab9a27aef9688204fe4ae25789444ea2e13119a87cfb8da7ce02d7'
};
const { createHash } = await import('node:crypto');

for (const theme of themes) {
  const url = new URL(`../frontend/bookmarks/bookmark-${theme}.webp`, import.meta.url);
  const bytes = fs.readFileSync(url);
  assert.equal(bytes.subarray(0, 4).toString('ascii'), 'RIFF', `${theme}: invalid RIFF header`);
  assert.equal(bytes.subarray(8, 12).toString('ascii'), 'WEBP', `${theme}: invalid WebP header`);
  assert.ok(bytes.length > 50_000, `${theme}: asset unexpectedly small`);
  assert.ok(bytes.length < 180_000, `${theme}: asset is not optimized`);
  assert.equal(createHash('sha256').update(bytes).digest('hex'), expectedSha256[theme], `${theme}: 040 bookmark asset changed`);
}

const legacyPng = fs.readdirSync(new URL('../frontend/bookmarks/', import.meta.url)).filter(name => name.endsWith('.png'));
assert.deepEqual(legacyPng, [], 'short/legacy PNG bookmarks remain');

console.log('long-bookmark-assets: 10 unchanged optimized WebP assets passed');
