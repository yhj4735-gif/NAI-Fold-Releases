import fs from 'node:fs';
import assert from 'node:assert/strict';

const html=fs.readFileSync(new URL('../frontend/index.html',import.meta.url),'utf8');
const conf=JSON.parse(fs.readFileSync(new URL('../src-tauri/tauri.conf.json',import.meta.url),'utf8'));
const workflow=fs.readFileSync(new URL('../build.yml',import.meta.url),'utf8');
const channel=JSON.parse(fs.readFileSync(new URL('../frontend/release-channel.json',import.meta.url),'utf8'));
const history=JSON.parse(fs.readFileSync(new URL('../frontend/changelog.json',import.meta.url),'utf8'));

assert.equal(conf.version,'1.0.0');
assert.equal(conf.identifier,'com.naifold.studio');
assert.ok(conf.bundle.android.versionCode>=2099000075);
assert.ok(channel.repository,'release repository must remain configured');
assert.ok(channel.tag,'release tag/mode must remain configured');
assert.ok(channel.build>=72);
assert.ok(history.currentBuild>=72);
assert.ok(history.releases.some(x=>x.build===72));

// Ratio family classifier: aspect is primary; CSS width alone must never turn Fold 10:9 into Compact.
assert.match(html,/let family='phone'/);
assert.match(html,/if\(key==='10-9'\|\|key==='4-3'\)family='fold'/);
assert.match(html,/else if\(key==='21-9'&&portrait&&longRatio>=2\.25\)family='compact'/);
assert.match(html,/else if\(key==='10-16'&&physicalShort>=1200\)family='tablet'/);
assert.match(html,/classList\.toggle\('compact-071',family==='compact'\)/);
assert.doesNotMatch(html,/w<=560\|\|\['21-9','10-16','19-5-9'\]/);
for(const cls of ['layout-fold072','layout-tablet072','layout-phone072','layout-compact072']) assert.ok(html.includes(cls),`missing ${cls}`);

function family({w,h,key,dpr=1}){
  const portrait=w<h,longRatio=Math.max(w,h)/Math.min(w,h),physicalShort=Math.min(w,h)*dpr;
  if(key==='10-9'||key==='4-3')return'fold';
  if(key==='21-9'&&portrait&&longRatio>=2.25)return'compact';
  if(key==='10-16'&&physicalShort>=1200)return'tablet';
  if(!portrait&&longRatio<=1.85)return'tablet';
  return'phone';
}
assert.equal(family({w:540,h:600,key:'10-9',dpr:2}),'fold','Fold CSS 540px must stay wide');
assert.equal(family({w:882,h:1050,key:'10-9',dpr:1}),'fold');
assert.equal(family({w:390,h:910,key:'21-9',dpr:3}),'compact');
assert.equal(family({w:360,h:840,key:'21-9',dpr:3}),'compact');
assert.equal(family({w:390,h:844,key:'19-5-9',dpr:3}),'phone');
assert.equal(family({w:800,h:1280,key:'10-16',dpr:2}),'tablet');
assert.equal(family({w:1280,h:800,key:'10-16',dpr:2}),'tablet');

// 071 global absolute regression is neutralized in the final authority.
const authority072=html.match(/<style id="authority072">([\s\S]*?)<\/style>/)?.[1]||'';
assert.match(authority072,/#generateBtn[^}]*position:relative!important/);

// Build 072's chat-room implementation is historical. Build 073 intentionally replaces it with one-shot AI requests.
if(channel.build===72){
  for(const id of ['storyRoomSelect072','storyNewRoom072','storyDeleteRoom072']) assert.ok(html.includes(`id="${id}"`),`missing ${id}`);
  assert.match(html,/STORY_ROOMS_KEY072='nai-fold-story-rooms-v072'/);
  assert.match(html,/const conversation072=buildStoryConversationContext072\(\)/);
}


// Runtime-critical external AI helpers must exist before the initialization loop.
for(const fn of ['formatTokens070','formatUsd070','renderExternalUsage070','providerModelListId070','likelyTextModel070','knownExternalModels070','modelStatusLabel070','renderExternalModelOptions070','providerActionKey070']){
  assert.ok(html.includes(`function ${fn}(`),`missing runtime helper ${fn}`);
}
const firstRenderExternalCall=html.indexOf('renderExternalModelOptions070(provider070)');
const renderExternalDef=html.indexOf('function renderExternalModelOptions070(provider)');
assert.ok(renderExternalDef>=0&&firstRenderExternalCall>renderExternalDef,'external model helper must be defined before startup initialization call');
assert.ok(html.indexOf('function renderExternalUsage070()') < html.lastIndexOf('renderExternalUsage070();'),'external usage renderer must exist before startup call');

// Build 072 remains present in bundled history even after the release channel advances.
assert.ok(history.releases.some(x=>x.build===72));

// Requested preserved identity/signing guard.
assert.match(workflow,/d98486c90903842258548b7a36dd23ad0aeca42c28ba8c64200bba408b1afa1a/);
assert.match(workflow,/186e5c132f7c440bdb0cd96a2854089012cfbcecddee483df4a59bc96d1e1fb9/);

console.log('device-regressions-072: ratio families, chat rooms, release archive passed');
