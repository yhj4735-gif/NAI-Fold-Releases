import assert from 'node:assert/strict';
import fs from 'node:fs';

const html = fs.readFileSync(new URL('../frontend/index.html', import.meta.url), 'utf8');
const rust = fs.readFileSync(new URL('../src-tauri/src/lib.rs', import.meta.url), 'utf8');

assert.match(html, /\.panel\.open,#comicModal\.diary-comic-page\{/);
assert.match(html, /inset:calc\(var\(--safe-top,0px\) \+ var\(--usable-head042\)\) 0 var\(--safe-bottom,0px\) 0!important/);
assert.match(html, /body\.panel-active \.app::after\{[\s\S]*?bottom:0!important;[\s\S]*?width:calc\(var\(--rail-hit038\) \+ 12px\)!important/);
assert.match(html, /\.diary-generate-tab\{[\s\S]*?position:fixed!important;z-index:342!important/);
assert.match(html, /\.comic-canvas\.has-source>\.comic-source-private\{display:flex!important/);
assert.match(html, /window\.diaryNav\?\.active==='dialogue'\) renderComicEditor\(\)/);
assert.match(html, /#panel-ai \.chat-log\{[\s\S]*?min-height:260px!important/);
assert.match(html, /bottom:calc\(var\(--safe-bottom,0px\) \+ 16px\)!important/);
assert.match(html, /long\?5200:2400/);
assert.match(rust, /https:\/\/text\.novelai\.net/);
assert.match(rust, /fn save_comic_png\(app: tauri::AppHandle/);
assert.match(html, /navigator\.canShare\?\.\(\{files:\[file\]\}\)/);

for (const id of ['panel-ai','panel-workspace','panel-settings','comicModal']) {
  assert.ok(html.includes(`id="${id}"`), `missing fullscreen workspace ${id}`);
}

console.log('device-regressions: privacy, rail action, story, save, toast and fullscreen assertions passed');
