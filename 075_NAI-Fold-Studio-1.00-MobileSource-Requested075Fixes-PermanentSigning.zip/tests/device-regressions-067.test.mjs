import fs from 'node:fs';
import assert from 'node:assert/strict';
const html=fs.readFileSync(new URL('../frontend/index.html',import.meta.url),'utf8');
const conf=JSON.parse(fs.readFileSync(new URL('../src-tauri/tauri.conf.json',import.meta.url),'utf8'));
assert.ok(conf.bundle.android.versionCode>=2099000069);
// History header is two rows and the duplicate main-image heading is gone.
assert.match(html,/home-history-head066 home-history-head067/);
assert.match(html,/grid-template-rows:auto auto!important/);
assert.doesNotMatch(html,/<section class="notebook-left home-workspace">\s*<div class="notebook-heading">최근 이미지<\/div>/);
// Story gets dynamically calculated bottom scroll reserve.
assert.match(html,/--story-bottom-space067/);
assert.match(html,/function updateStoryBottomSpace067\(\)/);
assert.match(html,/ResizeObserver\(updateStoryBottomSpace067\)/);
// Comic header is structurally split into title/actions/close and object label is inline.
assert.match(html,/comic-head066 comic-head067/);
assert.match(html,/comic-head-title036 comic-head-title067/);
assert.match(html,/comic-head-actions066 comic-head-actions067/);
assert.match(html,/class="close comic-close067"/);
assert.match(html,/type-summary type-summary067/);
assert.match(html,/selected-object-line067/);
assert.match(html,/grid-template-columns:minmax\(285px,1fr\) max-content max-content!important/);
// Prompt / Settings titles share bright lime.
assert.match(html,/#panel-workspace>\.panel-head \.panel-title,#panel-settings>\.panel-head \.panel-title\{color:#d8ffba!important/);
// Deep/category-aware wildcard translations and quality ranking.
assert.match(html,/KO_PHRASE_DEEP067/);
assert.match(html,/'smile_precure!':'스마일 프리큐어!'/);
assert.match(html,/rape_face:'강간 상황의 표정'/);
assert.match(html,/rapeseed:'유채'/);
assert.match(html,/function danbooruTagToKorean067\(/);
assert.match(html,/DANBOORU_CATEGORY067/);
assert.match(html,/function rankDanbooruTags067\(/);
assert.match(html,/category===0/);
assert.match(html,/fetchDanbooruTagsStable067/);
assert.match(html,/setTimeout\(runEditorTagSuggestions048,540\)/);
assert.match(html,/setTimeout\(\(\)=>runWildcardSearch047\(\),540\)/);
assert.doesNotMatch(html,/>추천 검색 실패</);
console.log('device-regressions-067: two-row history, Story scroll reserve, structural Comic header, title color, deep translation and stable ranked Danbooru autocomplete passed');
