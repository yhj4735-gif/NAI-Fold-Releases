import assert from 'node:assert/strict';
import fs from 'node:fs';

const html=fs.readFileSync(new URL('../frontend/index.html',import.meta.url),'utf8');
const rust=fs.readFileSync(new URL('../src-tauri/src/lib.rs',import.meta.url),'utf8');
const config=JSON.parse(fs.readFileSync(new URL('../src-tauri/tauri.conf.json',import.meta.url),'utf8'));

assert.equal(config.identifier,'com.naifold.studio');
assert.equal(config.version,'1.0.0');
assert.ok(config.bundle.android.versionCode>=2099000051);
assert.match(html,/data-diary-label="도구"><span>도구<\/span>/);
assert.match(html,/id="overlayText" aria-label="선택 오버레이 텍스트"/);
assert.doesNotMatch(html,/id="editOverlayText051"/);
assert.match(html,/overlayText'\)\?\.addEventListener\('input'/);
assert.match(html,/id="overlayJoystickPad051"/);
assert.match(html,/data-overlay-drag051/);
assert.match(html,/position-face051/);
assert.match(html,/character\.faceImage/);
assert.match(html,/bindAndroidBack051/);
assert.match(html,/bookmarkRuntime038\?\.lockedPage/);
assert.match(html,/blood_on_clothes:'옷에 묻은 피'/);
assert.match(html,/'limit':'100'/);
assert.match(rust,/oa\/v1\/completions/);
assert.match(rust,/oa\/v1\/chat\/completions/);
assert.match(rust,/extract_choice_text/);
assert.match(rust,/\("limit", "100"\)/);
assert.doesNotMatch(rust,/eprintln!\([^;]*(token|Authorization)/s);

console.log('device-regressions-051: comic touch, joystick, avatar positions, Android back, Danbooru translation and NovelAI completion fallback passed');
