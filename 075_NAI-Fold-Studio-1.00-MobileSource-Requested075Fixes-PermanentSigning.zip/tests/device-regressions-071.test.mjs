import fs from 'node:fs';
import assert from 'node:assert/strict';

const html=fs.readFileSync(new URL('../frontend/index.html',import.meta.url),'utf8');
const rust=fs.readFileSync(new URL('../src-tauri/src/lib.rs',import.meta.url),'utf8');
const cargo=fs.readFileSync(new URL('../src-tauri/Cargo.toml',import.meta.url),'utf8');
const cap=JSON.parse(fs.readFileSync(new URL('../src-tauri/capabilities/default.json',import.meta.url),'utf8'));
const conf=JSON.parse(fs.readFileSync(new URL('../src-tauri/tauri.conf.json',import.meta.url),'utf8'));
const workflow=fs.readFileSync(new URL('../build.yml',import.meta.url),'utf8');
const channel=JSON.parse(fs.readFileSync(new URL('../frontend/release-channel.json',import.meta.url),'utf8'));
const history=JSON.parse(fs.readFileSync(new URL('../frontend/changelog.json',import.meta.url),'utf8'));

assert.equal(conf.version,'1.0.0');
assert.equal(conf.identifier,'com.naifold.studio');
assert.ok(conf.bundle.android.versionCode>=2099000075);

// 072 intentionally replaces 071's width-only compact trigger; 071 feature CSS remains retained.
assert.match(html,/classList\.toggle\('compact-071',family==='compact'\)/);
assert.doesNotMatch(html,/classList\.toggle\('compact-071',w<h&&\(w<=560/);
const revised=html.match(/<style id="authority071-revised">([\s\S]*?)<\/style>/)?.[1]||'';
assert.ok(revised.length>1500,'missing revised 071 authority');
assert.match(revised,/body\.compact-071 \.main-image-save068\{[^}]*position:static!important/);
assert.match(revised,/body\.compact-071 \.home-history-list\{[^}]*flex-direction:row!important/);
assert.match(revised,/body\.compact-071 #panel-workspace \.panel-body\.workspace-body032\{[^}]*grid-template-columns:1fr!important/);
assert.match(revised,/body\.compact-071 \.workspace-column032\{[^}]*height:auto!important/);
assert.match(revised,/@media\(pointer:coarse\)\{body\.compact-071 #panel-ai \.panel-body\{[^}]*\+ 10px/);
assert.doesNotMatch(revised,/#panel-ai \.panel-body\{[^}]*\+ 68px/);
assert.match(revised,/body\.compact-071 #comicModal\.diary-comic-page\{padding-right:26px!important/);
assert.match(revised,/#generateBtn\{position:absolute!important;overflow:hidden!important\}/);
assert.match(revised,/#generateBtn \.gen-spinner068\{[^}]*position:absolute!important/);

// Header cleanup: external usage moves into API modal; NovelAI status remains high contrast and LOCAL keeps bookmark actions.
assert.doesNotMatch(html,/<button[^>]+id="topAiUsage070"/);
assert.match(html,/id="apiMonthUsage071"/);
assert.match(html,/이번 달 외부 AI 사용량/);
assert.match(html,/monthProviders/);
assert.match(html,/monthModels/);
assert.match(html,/기존 통합 기록/);
assert.match(revised,/#topUsageBar[^}]*color:#f5fff4!important/);
assert.match(revised,/body\.top-info-collapsed070 \.top-actions\{display:flex!important\}/);
assert.match(revised,/body\.compact-071\.top-info-collapsed070 \.top-actions/);

// Privacy cycles full hide -> history only -> all visible, while legacy privacy keeps large images hidden in history-only.
assert.match(html,/\['all-hidden','history-only','all-visible'\]/);
assert.match(html,/function privacyMainHidden071\(\)\{return state\.privacyMode071!==\'all-visible\'\}/);
assert.match(html,/function privacyHistoryHidden071\(\)\{return state\.privacyMode071===\'all-hidden\'\}/);
assert.match(html,/Privacy · 히스토리만 보임/);
assert.match(html,/if\(privacyHistoryHidden071\(\)\)/);

// Gelbooru is optional and configured above OpenAI with optional credentials.
const gelPos=html.indexOf('gelbooru-provider071');
const openaiPos=html.indexOf('<strong>GPT · OpenAI</strong>');
assert.ok(gelPos>=0 && openaiPos>gelPos,'Gelbooru card must be above OpenAI');
assert.match(html,/id="gelbooruEnabled071"/);
assert.match(html,/id="gelbooruAuthMode071"/);
assert.match(html,/<option value="anonymous">비로그인<\/option>/);
assert.match(html,/<option value="auth">API 인증<\/option>/);
assert.match(html,/id="gelbooruUserId071"/);
assert.match(html,/id="gelbooruKey071"/);
assert.match(html,/if\(!state\.gelbooruEnabled071\)return mergeBooruTags071\(await fetchDanbooruTagsStable067\(query\),\[\]\)/);
assert.match(rust,/"gelbooru"\s*=>\s*"gelbooru_api_key"/);
assert.match(rust,/async fn fetch_gelbooru_tags\([\s\S]*user_id: Option<String>[\s\S]*api_key: Option<String>/);

// Hardcoded help paths with strict native URL allowlist.
for(const provider of ['gelbooru','openai','gemini','grok']) assert.match(html,new RegExp(`data-api-help071="${provider}"`));
assert.match(html,/Gelbooru 로그인 → My Account \/ Options → API Access Credentials/);
assert.match(html,/OpenAI Platform → Settings → Project → API Keys → Create new secret key/);
assert.match(html,/Google AI Studio → Dashboard → API Keys → Create API key/);
assert.match(html,/xAI Console → API Keys → Create API Key/);
assert.match(html,/nativeInvoke\('open_help_url'/);
assert.match(rust,/fn open_help_url/);
for(const domain of ['https://gelbooru.com/','https://platform.openai.com/','https://aistudio.google.com/','https://console.x.ai/']) assert.ok(rust.includes(domain),`missing help allowlist ${domain}`);

// External model choice is app-owned and readonly so Android keyboard does not open.
for(const id of ['openAiModel055','geminiModel055','grokModel055','externalAiModel055']){
  const tag=html.match(new RegExp(`<input[^>]+id="${id}"[^>]*>`))?.[0]||'';
  assert.ok(tag,'missing model input '+id);
  assert.doesNotMatch(tag,/\slist=/,'native datalist must not be attached to '+id);
  assert.match(tag,/\sreadonly(?:\s|>)/,'model selector must be readonly: '+id);
  assert.match(tag,/inputmode="none"/,'model selector must suppress keyboard: '+id);
}
assert.match(html,/className='model-picker071'/);
assert.match(html,/function openModelPicker071/);
assert.match(html,/API 설정에서 모델 조회를 먼저 실행해 주세요/);
assert.doesNotMatch(html,/modelPicker071[\s\S]{0,2200}input\.focus\(\)/);

// NovelAI: final JSON preferred, stream/chunk parser retained as fallback, token_ids never surfaced as prose.
assert.match(rust,/fn parse_streamed_json_body/);
assert.match(rust,/trimmed\.contains\("\\"token_ids\\""\)/);
assert.match(rust,/"stream": false/);
assert.match(rust,/\.header\("Accept", "application\/json"\)/);
assert.match(rust,/"_naifold_text": text/);
assert.match(rust,/Chat 시도: \{\} \/ Completion 시도: \{\}/);

// Update repository is never empty and is pinned/validated in CI.
assert.equal(channel.repository,'yhj4735-gif/NAI-Fold-Releases');
assert.equal(channel.tag,'latest');
assert.ok(channel.build>=74);
assert.equal((workflow.match(/- name: Stamp release channel/g)||[]).length,2);
assert.ok((workflow.match(/source_repo\s*=\s*['\"]yhj4735-gif\/NAI-Fold-Studio['\"]/g)||[]).length>=2);
assert.match(workflow,/Unexpected GitHub repository/);
assert.match(workflow,/repository['"]?:?\s*['"]yhj4735-gif\/NAI-Fold-Releases/);
assert.match(workflow,/BUILD3|CHANGELOG/);
assert.match(workflow,/release-manifest\.json/);

// Version/update feature and dont-ask remain.
const helpPos=html.indexOf('data-settings-tab="help"'),versionPos=html.indexOf('data-settings-tab="version"');
assert.ok(helpPos>=0 && versionPos>helpPos,'Version tab must follow Feature Guide');
assert.match(html,/id="versionDontAsk071"/);
assert.match(html,/업데이트 묻지 않기/);
assert.ok(history.currentBuild>=74);
assert.ok((history.releases[0]?.build||0)>=74);
assert.ok(history.releases.some(x=>x.build===71));
assert.ok(history.releases.some(x=>x.build===70));
assert.ok(history.releases.some(x=>x.build===69));
assert.match(cargo,/tauri-plugin-opener = "2"/);
assert.ok(cap.permissions.includes('opener:default'));

// User explicitly kept provider live-test behavior and current error classification.
assert.match(rust,/async fn test_external_ai_model/);
assert.match(html,/선택 모델 테스트/);
for(const provider of ['openai','gemini','grok']) assert.match(html,new RegExp(`data-ai-model-test070="${provider}"`));

console.log('device-regressions-071: revised requested-only assertions passed');
