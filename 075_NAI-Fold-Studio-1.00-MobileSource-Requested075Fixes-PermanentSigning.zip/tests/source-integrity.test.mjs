import assert from 'node:assert/strict';
import fs from 'node:fs';

const html = fs.readFileSync(new URL('../frontend/index.html', import.meta.url), 'utf8');
const rust = fs.readFileSync(new URL('../src-tauri/src/lib.rs', import.meta.url), 'utf8');
const config = JSON.parse(fs.readFileSync(new URL('../src-tauri/tauri.conf.json', import.meta.url), 'utf8'));
const themes = ['white','dark','nai','spring','summer','autumn','winter','cherry','mountain','sea'];

for (const theme of themes) {
  assert.ok(fs.existsSync(new URL(`../frontend/backgrounds/bg-${theme}.webp`, import.meta.url)), `missing background ${theme}`);
  assert.ok(fs.existsSync(new URL(`../frontend/bookmarks/bookmark-${theme}.webp`, import.meta.url)), `missing bookmark ${theme}`);
}

for (const legacy of ['bookmark-ribbon','bookmark-pull','bookmark-branch','bookmark-anchor','<iframe','webFrame037','webLauncher037','openWebBrowser037','plugin:opener|open_url']) {
  assert.equal(html.includes(legacy), false, `legacy implementation remains: ${legacy}`);
}

assert.match(html, /grid-template-columns:minmax\(174px,220px\) minmax\(300px,1fr\) var\(--bookmark-gutter038\)/);
assert.match(html, /page-bookmark038\[data-open="true"\]/);
assert.match(html, /translate3d\(0,calc\(-100% \+ var\(--bookmark-closed-peek041\)\),0\)/);
assert.doesNotMatch(html, /pageBookmarkPeekImage040|page-bookmark038-peek/);
const bookmarkMarkup = html.match(/<div class="page-bookmark038"[\s\S]*?<\/div>/)?.[0] || '';
assert.equal((bookmarkMarkup.match(/<img\b/g)||[]).length, 1, 'bookmark must render exactly one image');
assert.equal((html.match(/id="pageBookmarkImage038"/g)||[]).length, 1, 'bookmark image id must be unique');
assert.match(html, /position:fixed!important;z-index:390!important/);
assert.match(html, /\.topbar\{z-index:360!important/);
assert.match(html, /right:calc\(env\(safe-area-inset-right,0px\) \+ 22px\)!important/);
assert.match(html, /transform:translateX\(50%\)/);
assert.match(html, /transition:transform \.46s var\(--bookmark-ease040\)/);
assert.match(html, /object-fit:contain/);
assert.match(html, /confirmCharFaceCrop038/);
assert.match(html, /comicPngCanvasFallback037/);
assert.match(html, /SVG 합성 실패, Canvas fallback 사용/);
assert.match(rust, /fn save_comic_png/);
assert.match(rust, /async fn generate_story/);
assert.match(html, /nativeInvoke\('generate_story'/);
assert.match(rust, /const TEXT_API: &str = "https:\/\/text\.novelai\.net"/);
assert.doesNotMatch(rust, /const TEXT_API: &str = "https:\/\/api\.novelai\.net"/);
assert.match(rust, /\.app_data_dir\(\)/);
assert.doesNotMatch(html, /실제 API 호출은 아직 연결하지 않았습니다/);
assert.match(rust, /PNG\\r\\n\\x1a\\n/);
assert.equal(config.version, '1.0.0');
assert.ok(config.bundle.android.versionCode>=2099000075);

console.log('source-integrity: all assertions passed');
