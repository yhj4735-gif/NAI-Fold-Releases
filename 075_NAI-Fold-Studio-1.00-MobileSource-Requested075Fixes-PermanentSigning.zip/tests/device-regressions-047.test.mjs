import assert from 'node:assert/strict';
import fs from 'node:fs';

const html=fs.readFileSync(new URL('../frontend/index.html',import.meta.url),'utf8');
const rust=fs.readFileSync(new URL('../src-tauri/src/lib.rs',import.meta.url),'utf8');
const bookmark=fs.readFileSync(new URL('../frontend/bookmark-controller.js',import.meta.url),'utf8');
const syncIcon=fs.readFileSync(new URL('../ci/sync_android_launcher_icon.py',import.meta.url),'utf8');

assert.match(html,/nai-fold-symbol-047-white\.png/);
assert.ok(fs.existsSync(new URL('../frontend/assets034/nai-fold-symbol-047-navy.png',import.meta.url)));
assert.doesNotMatch(html,/nai-fold-symbol-044\.png/);
for(const name of ['nai-fold-symbol-047-white.png','nai-fold-symbol-047-navy.png','nai-fold-app-icon-047.png']){
  const bytes=fs.readFileSync(new URL(`../frontend/assets034/${name}`,import.meta.url));
  assert.equal(bytes.subarray(1,4).toString('ascii'),'PNG',`${name}: not PNG`);
  assert.equal(bytes[25],6,`${name}: must preserve RGBA transparency`);
}
assert.match(syncIcon,/nai-fold-symbol-047-white\.png/);
assert.match(syncIcon,/ic_launcher_round\.png/);

assert.match(bookmark,/case 'CLOSE_PAGE':[\s\S]*?allowed: true/);
assert.doesNotMatch(bookmark,/case 'CLOSE_PAGE':[\s\S]*?allowed: false/);
assert.doesNotMatch(html,/if\(window\.diaryNav\?\.locked\)\{[\s\S]{0,180}closeDiaryPanelAnimated/);

assert.match(html,/#promptEditorModal\{position:fixed!important/);
assert.match(html,/max-height:calc\(100dvh/);
assert.match(html,/card\.scrollTop=0/);

assert.match(html,/id="wildcardSearch"/);
assert.match(html,/id="wildcardResults"/);
assert.match(html,/id="wildcardSelected"/);
assert.match(html,/fetchDanbooruTags047/);
assert.match(html,/items\.join\(', '\)/);
assert.doesNotMatch(html,/insertTextAtCursor\('\|\|'/);
assert.match(rust,/fetch_danbooru_tags/);
assert.match(rust,/DANBOORU_API/);
assert.match(rust,/search\[name_matches\]/);
assert.match(rust,/search\[order\]", "count"/);

console.log('device-regressions-047: transparent symbol, tab-only bookmark lock, safe prompt modal and Danbooru comma-tag UI passed');
