import assert from 'node:assert/strict';
import fs from 'node:fs';

const html=fs.readFileSync(new URL('../frontend/index.html',import.meta.url),'utf8');
const rust=fs.readFileSync(new URL('../src-tauri/src/lib.rs',import.meta.url),'utf8');
const tauri=JSON.parse(fs.readFileSync(new URL('../src-tauri/tauri.conf.json',import.meta.url),'utf8'));

assert.equal(tauri.identifier,'com.naifold.studio');
assert.ok(tauri.bundle.android.versionCode>=2099000051);
assert.match(html,/data-advanced-action="randomizer"/);
assert.match(html,/id="advancedParamsModal"/);
assert.match(html,/id="referenceImageModal"/);
assert.match(html,/id="imageToolModal049"/);
assert.match(html,/nativeInvoke\('upscale_image'/);
assert.match(html,/function prepareInpaintPayload068\(/);
assert.match(html,/'헤어':'hair'/);
assert.match(html,/cachedDanbooruTags049/);
assert.match(html,/response\?\._naifold_text/);
assert.match(rust,/async fn upscale_image/);
assert.match(rust,/"_naifold_text"/);
assert.match(rust,/for attempt in 1\.\.=3/);
console.log('device-regressions-049: functional image tools, advanced settings, resilient tags and Story parser passed');
