import assert from 'node:assert/strict';
import '../frontend/bookmark-controller.js';

const B = globalThis.BookmarkController038;
let state = B.initial('spring');

// Main -> prompt -> downward slide: prompt becomes the pinned page.
assert.equal(B.reduce(state, { type: 'NAVIGATE', page: 'workspace' }).allowed, true);
state = B.reduce(state, { type: 'OPEN', activePage: 'workspace' }).state;
assert.deepEqual({ open: state.open, lockedPage: state.lockedPage }, { open: true, lockedPage: 'workspace' });

// While pinned, all four right-side tab actions are rejected; X remains usable.
assert.equal(B.reduce(state, { type: 'NAVIGATE', page: 'dialogue' }).allowed, false);
assert.equal(B.reduce(state, { type: 'NAVIGATE', page: 'workspace' }).allowed, false);
assert.equal(B.reduce(state, { type: 'CLOSE_PAGE' }).allowed, true);

// Upward slide closes the bookmark, unlocks, and navigation works again.
assert.equal(B.gesture(200, 160), 'CLOSE');
assert.equal(B.gesture(200, 207), 'NONE');
state = B.reduce(state, { type: 'CLOSE' }).state;
assert.deepEqual({ open: state.open, lockedPage: state.lockedPage }, { open: false, lockedPage: null });
assert.equal(B.reduce(state, { type: 'NAVIGATE', page: 'dialogue' }).allowed, true);

// Theme changes replace only the asset key and preserve open/lock state.
state = B.reduce(state, { type: 'OPEN', activePage: 'dialogue' }).state;
state = B.reduce(state, { type: 'THEME', theme: 'winter' }).state;
assert.deepEqual(state, { open: true, lockedPage: 'dialogue', theme: 'winter' });

// A bookmark opened on Main has no page to lock.
state = B.initial('sea');
state = B.reduce(state, { type: 'OPEN', activePage: null }).state;
assert.equal(state.open, true);
assert.equal(state.lockedPage, null);

console.log('bookmark-flow: all scenarios passed');
