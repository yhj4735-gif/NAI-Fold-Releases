import assert from 'node:assert/strict';

// Mirrors the final 038 CSS geometry so the three main columns never exceed a viewport.
const cases = [
  { name: 'Fold 1180x1320', width: 1180, height:1320, left: 12, rail: 58, history: 122, headLeft: 250, headRight: 92, headPad: 70, bookmarkMax:370, fold:true },
  { name: 'Fold 1080x1200', width: 1080, height:1200, left: 12, rail: 58, history: 122, headLeft: 250, headRight: 92, headPad: 70, bookmarkMax:370, fold:true },
  { name: 'Fold 882x1050', width: 882, height:1050, left: 12, rail: 52, history: 116, headLeft: 230, headRight: 86, headPad: 68, bookmarkMax:340, fold:true },
  { name: 'Android phone 390x844', width: 390, height:844, left: 6, rail: 48, history: 94, headLeft: 58, headRight: 70, headPad: 53, bookmarkMax:190, fold:false }
];

for (const c of cases) {
  const content = c.width - c.left - c.rail;
  const preview = content - c.history - 8;
  assert.ok(preview > 220, `${c.name}: preview is too narrow (${preview}px)`);
  assert.ok(c.left + preview + 8 + c.history + c.rail <= c.width, `${c.name}: horizontal overflow`);
  assert.ok(c.history >= 94, `${c.name}: history is too narrow`);
  const headerCenter = c.width - c.headPad - c.headLeft - c.headRight - 20;
  assert.ok(headerCenter >= 189, `${c.name}: header center collides (${headerCenter}px)`);
  const bookmarkWidth=Math.min(c.width*(c.fold ? .32 : .44),c.bookmarkMax),bookmarkHeight=bookmarkWidth*3,bookmarkShare=bookmarkHeight/c.height;
  const railCenter=c.width-22;
  const bookmarkCenter=c.width-22;
  assert.equal(bookmarkCenter,railCenter,`${c.name}: bookmark is not centred over the rail`);
  if(c.fold){
    assert.ok(bookmarkShare>=.80&&bookmarkShare<=.90,`${c.name}: long bookmark uses ${(bookmarkShare*100).toFixed(1)}%`);
    const safeTop=34,safeBottom=44,openTop=safeTop+4;
    assert.ok(openTop+bookmarkHeight<c.height-safeBottom,`${c.name}: bookmark reaches the system bar`);
    const closedVisibleBelowSafeArea=Math.max(0,(safeTop+4+4)-safeTop);
    assert.ok(closedVisibleBelowSafeArea<=8,`${c.name}: closed bookmark exposes too much (${closedVisibleBelowSafeArea}px)`);
  }
  console.log(`${c.name}: preview ${preview}px / history ${c.history}px / rail ${c.rail}px / header center ${headerCenter}px / bookmark ${(bookmarkShare*100).toFixed(1)}%`);
}
