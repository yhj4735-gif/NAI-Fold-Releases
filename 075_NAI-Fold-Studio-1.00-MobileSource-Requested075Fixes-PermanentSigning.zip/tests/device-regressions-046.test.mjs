import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';

const html=fs.readFileSync(new URL('../frontend/index.html',import.meta.url),'utf8');
const rust=fs.readFileSync(new URL('../src-tauri/src/lib.rs',import.meta.url),'utf8');
const workflow=fs.readFileSync(new URL('../build-auto-latest-release-updatefix-v8-stable-signing-icon.yml',import.meta.url),'utf8');
const iconScript=fs.readFileSync(new URL('../ci/sync_android_launcher_icon.py',import.meta.url),'utf8');
const tauri=JSON.parse(fs.readFileSync(new URL('../src-tauri/tauri.conf.json',import.meta.url),'utf8'));

assert.equal(tauri.identifier,'com.naifold.studio');
assert.ok(tauri.bundle.android.versionCode>=2099000051);
assert.match(workflow,/2_099_000_046 <= code <= 2_147_000_000/);
assert.doesNotMatch(workflow,/assert code == 2_099_000_046/);
assert.match(workflow,/install -m 600 ci\/android-debug\.keystore src-tauri\/gen\/android\/app\/debug\.keystore/);
assert.match(workflow,/APKSIGNER.*verify --print-certs/);
assert.match(workflow,/test "\$ACTUAL" = "\$EXPECTED"/);
assert.match(workflow,/python ci\/sync_android_launcher_icon\.py/);
assert.match(iconScript,/nai-fold-symbol|src-tauri/);
assert.match(iconScript,/ic_launcher_round\.png/);
assert.match(html,/function parseNovelAIText046/);
assert.match(html,/choice\?\.message\?\.content/);
assert.match(html,/choice\?\.text/);
assert.match(html,/choice\?\.parsedContent/);
assert.match(html,/choice\?\.delta\?\.content/);
assert.match(html,/NovelAI 응답 파싱 실패/);
assert.match(rust,/"stream": false/);
assert.match(rust,/\[NovelAI Text 054\] status=/);
assert.match(rust,/content-type=/);
assert.match(rust,/chars=/);
const diagnosticLines=rust.split('\n').filter(line=>line.includes('[NovelAI Text 054]')).join('\n');
assert.doesNotMatch(diagnosticLines,/bearer|Authorization|token\s*[,)]/);
assert.match(html,/\.topbar\{z-index:2200!important\}/);
assert.match(html,/\.page-bookmark038\{z-index:2250!important\}/);

const parserSource=html.match(/function textFromNovelAINode046[\s\S]*?\n}\nfunction parseNovelAIText046[\s\S]*?\n}/)?.[0];
assert.ok(parserSource,'NovelAI response parser source must be extractable');
const sandbox={console:{info(){}}};
vm.createContext(sandbox);
vm.runInContext(parserSource,sandbox);
assert.equal(sandbox.parseNovelAIText046({choices:[{message:{content:'message result'}}]},'m'),'message result');
assert.equal(sandbox.parseNovelAIText046({choices:[{text:'text result'}]},'m'),'text result');
assert.equal(sandbox.parseNovelAIText046({choices:[{parsedContent:'parsed result'}]},'m'),'parsed result');
assert.equal(sandbox.parseNovelAIText046({choices:[{delta:{content:'delta result'}}]},'m'),'delta result');
assert.equal(sandbox.parseNovelAIText046({choices:[{message:{content:[{type:'text',text:'part one'},{content:'part two'}]}}]},'m'),'part one\npart two');

console.log('device-regressions-046: stable signing guard, launcher synchronization, bookmark stacking and NovelAI parser diagnostics passed');
