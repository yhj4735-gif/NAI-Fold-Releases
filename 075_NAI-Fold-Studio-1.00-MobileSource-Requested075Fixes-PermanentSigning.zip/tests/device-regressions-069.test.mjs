import fs from 'node:fs';
import assert from 'node:assert/strict';

const html=fs.readFileSync(new URL('../frontend/index.html',import.meta.url),'utf8');
const rust=fs.readFileSync(new URL('../src-tauri/src/lib.rs',import.meta.url),'utf8');
const cargo=fs.readFileSync(new URL('../src-tauri/Cargo.toml',import.meta.url),'utf8');
const conf=JSON.parse(fs.readFileSync(new URL('../src-tauri/tauri.conf.json',import.meta.url),'utf8'));
assert.equal(conf.version,'1.0.0');
assert.equal(conf.identifier,'com.naifold.studio');
assert.ok(conf.bundle.android.versionCode>=2099000069);

function functionSource(name){
  const marker=`function ${name}(`,start=html.indexOf(marker);assert.ok(start>=0,`missing ${name}`);
  const brace=html.indexOf('{',start);let depth=0,inString='',escape=false;
  for(let i=brace;i<html.length;i++){
    const ch=html[i];
    if(inString){if(escape){escape=false;continue}if(ch==='\\'){escape=true;continue}if(ch===inString)inString='';continue}
    if(ch==='"'||ch==="'"||ch==='`'){inString=ch;continue}
    if(ch==='{')depth++;else if(ch==='}'&&--depth===0)return html.slice(start,i+1);
  }
  throw new Error(`unterminated ${name}`);
}

// Korean wildcard/Danbooru search: one-character Hangul + proper-name reverse lookup + no garbage phonetic fallback for general tags.
assert.match(html,/Object\.assign\(KO_QUERY_048,\{'입':'mouth','옷':'clothes','의상':'clothes','손':'hand','발':'feet','눈동자':'pupils'\}\)/);
assert.match(html,/clothes_pull:'옷을 잡아당김'/);
assert.match(html,/sky_lantern:'풍등'/);
assert.match(html,/tagTranslationCacheSchema069/);
assert.match(html,/function tagTranslationEntry069\(/);
const humanize=functionSource('humanizeGeneralTag067');
assert.doesNotMatch(humanize,/romanWordToHangul066/);
const roman=Function(`return (${functionSource('hangulRomanCandidates069')})`)();
assert.ok(roman('아이샤').includes('aisha'),'아이샤 must produce aisha reverse-search candidate');
const wildcardSearch=functionSource('runWildcardSearch047');
assert.match(wildcardSearch,/containsHangul048\(entered\)/);
assert.match(wildcardSearch,/properCandidates/);
const editorSearch=functionSource('runEditorTagSuggestions048');
assert.match(editorSearch,/hangulRomanCandidates069/);
assert.match(editorSearch,/entered\.length<2&&!containsHangul048\(entered\)/);

// Comic header: close stays in its own safe column; narrow widths wrap only action buttons.
assert.match(html,/#comicModal \.modal-head\.comic-head067\{grid-template-columns:minmax\(0,1fr\) max-content 40px!important/);
assert.match(html,/#comicModal \.comic-close067\{position:static!important/);
assert.match(html,/grid-template-areas:"title close" "actions actions"!important/);
assert.match(html,/\.comic-close067\{grid-area:close!important/);

// Full history is integrated into Gallery/History and uses fixed-content rows + paged rendering.
assert.match(html,/id="galleryHistoryView069"/);
assert.match(html,/id="historyDeleteMode069"/);
assert.match(html,/id="historySelectNonFavorite069"/);
assert.match(html,/id="historyDeleteConfirm069"/);
assert.match(html,/id="historyAutoDelete069"/);
assert.match(html,/grid-auto-rows:max-content!important/);
assert.ok(/historyGridVisible069=40/.test(html)||/HISTORY_PAGE_SIZE070=30/.test(html));
assert.ok(/historyGridVisible069\+40/.test(html)||/data-history-page070/.test(html));
assert.match(html,/selected-delete069/);
assert.match(html,/thumb:\$\{key\}/);
const openHistory=functionSource('openHistoryGallery068');
assert.match(openHistory,/openPanel\('gallery'\)/);
assert.match(openHistory,/setGalleryHistoryMode069\(true\)/);
assert.doesNotMatch(openHistory,/showModal\('historyGallery068'\)/);
assert.match(html,/function enforceHistoryAutoDelete069[\s\S]*?const nonFav=all\.filter\(x=>!x\.favorite\)[\s\S]*?nonFav\.slice\(value\)/);

// Generate button: fixed box, reserved refresh icon slot, icon-only rotation.
assert.match(html,/gen-spinner068" aria-hidden="true">↻<\/span>/);
assert.match(html,/#generateBtn\{height:78px!important;min-height:78px!important;max-height:78px!important/);
assert.match(html,/#generateBtn \.gen-spinner068\{display:flex!important;visibility:hidden!important/);
assert.match(html,/#generateBtn\.generating \.gen-spinner068\{visibility:visible!important;animation:spin069/);
assert.match(html,/@keyframes spin069/);

// Story chat uses remaining panel height instead of a fixed dvh box while retaining bottom reserve.
assert.match(html,/#storyPanelBody066\{display:flex!important/);
assert.match(html,/#panel-ai \.ai-shell\{display:flex!important;flex:0 0 calc\(100% \+ var\(--story-bottom-space067\)\)!important/);
assert.match(html,/#panel-ai \.chat-log\{flex:1 1 260px!important;height:auto!important/);
assert.match(html,/--story-bottom-space067/);

// Upscale: core API + actual dimensions/scale + ZIP extraction + MIME signature validation.
assert.match(rust,/const CORE_API: &str = "https:\/\/api\.novelai\.net"/);
assert.match(rust,/async fn upscale_image\(token: String, image: String, width: u32, height: u32, scale: u32\)/);
assert.match(rust,/\.post\(format!\("\{CORE_API\}\/ai\/upscale"\)\)/);
assert.match(rust,/json!\(\{"image": image, "width": width, "height": height, "scale": scale\}\)/);
assert.match(rust,/zip::ZipArchive::new/);
assert.match(rust,/fn sniff_image_mime/);
assert.match(cargo,/zip = \{ version = "2\.2"/);
assert.match(html,/nativeInvoke\('upscale_image',\{token:runtimeApiToken,image:raw,width:imageToolSourceSize069\.width,height:imageToolSourceSize069\.height,scale\}\)/);

// Inpaint: source-pixel mask, brush/eraser, dedicated prompt, black/white mask and empty-mask guard.
assert.match(html,/id="inpaintPromptMode069"/);
assert.match(html,/id="inpaintBrushSize069"/);
assert.match(html,/id="inpaintEraser069"/);
assert.match(html,/canvas\.width=w;canvas\.height=h/);
const mask=functionSource('buildInpaintMask069');
assert.match(mask,/fillStyle='#000'/);
assert.match(mask,/on\?255:0/);
assert.match(mask,/if\(!painted\)throw new Error/);
assert.match(html,/payload\.parameters\.width=imageToolSourceSize069\.width/);
assert.match(html,/payload\.parameters\.height=imageToolSourceSize069\.height/);
assert.match(html,/inpaintPromptMode069/);

// Tool results remain non-destructive: new entries are unshifted; originals are not overwritten.
const storeTool=functionSource('storeToolResult049');
assert.match(storeTool,/state\.history\.unshift\(entry\)/);
assert.doesNotMatch(storeTool,/state\.history\[[^\]]+\]\s*=\s*entry/);

console.log('device-regressions-069: requested-only fixes passed');
