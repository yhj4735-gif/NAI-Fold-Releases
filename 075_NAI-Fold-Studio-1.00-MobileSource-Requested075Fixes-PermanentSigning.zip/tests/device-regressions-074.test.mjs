import fs from 'node:fs';
import assert from 'node:assert/strict';

const html=fs.readFileSync(new URL('../frontend/index.html',import.meta.url),'utf8');
const conf=JSON.parse(fs.readFileSync(new URL('../src-tauri/tauri.conf.json',import.meta.url),'utf8'));
const workflow=fs.readFileSync(new URL('../build.yml',import.meta.url),'utf8');
const channel=JSON.parse(fs.readFileSync(new URL('../frontend/release-channel.json',import.meta.url),'utf8'));
const history=JSON.parse(fs.readFileSync(new URL('../frontend/changelog.json',import.meta.url),'utf8'));

// Identity/install continuity.
assert.equal(conf.version,'1.0.0');
assert.equal(conf.identifier,'com.naifold.studio');
assert.ok(conf.bundle.android.versionCode>=2099000075);
assert.equal(channel.repository,'yhj4735-gif/NAI-Fold-Releases');
assert.ok(channel.build>=74);
assert.ok(history.currentBuild>=74);
assert.ok((history.releases[0]?.build||0)>=74);

// Requested LOCAL collapse must win over later compact header rules.
const a=html.match(/<style id="authority074">([\s\S]*?)<\/style>/)?.[1]||'';
assert.ok(a.length>1000,'missing 074 authority');
assert.match(a,/body\.top-info-collapsed070 \.topbar-meta\{display:none!important\}/);

// Main: reuse the one existing generate action inside preview controls; do not duplicate it.
assert.equal((html.match(/id="generateBtn"/g)||[]).length,1);
const previewPos=html.indexOf('<div class="preview-wrap');
const generatePos=html.indexOf('id="generateBtn"');
const historyPos=html.indexOf('class="home-history-wrap"',generatePos);
assert.ok(previewPos>=0 && generatePos>previewPos && historyPos>generatePos,'generate/history order must be preview -> generate -> history');
assert.equal((html.match(/id="generateBtn"/g)||[]).length,1);
assert.match(a,/body\.layout-compact072\.diary-portrait\.ratio-21-9 \.home-workspace\{height:auto!important/);
assert.match(a,/body\.layout-compact072\.diary-portrait\.ratio-21-9 \.home-history-wrap\{margin-top:0!important\}/);

// Prompt: requested minimal compact 21:9 change is only a downward offset for Character Prompt.
assert.match(html,/workspace-character032/);

// Dialogue: Enter newline path remains explicit for horizontal and vertical, plus per-overlay/default font controls.
assert.match(html,/vertical-line075/);
for(const id of ['overlayFontFamily074','comicDefaultFont074']) assert.match(html,new RegExp(`id="${id}"`));
assert.match(html,/fontFamily074:state\.comicDefaultFont074\|\|'system'/);
assert.match(html,/node\.style\.fontFamily=comicFontFamily074\(item\.fontFamily074\)/);
assert.match(html,/ctx\.font=`900 \$\{font\}px \$\{comicFontFamily074\(item\.fontFamily074\)\}`/);

// Novel Story built-in questions: edit/add/delete + reset to app defaults.
for(const id of ['openStoryQuestions074','storyQuestionsModal074','storyQuestionList074','storyQuestionAdd074','storyQuestionReset074']) assert.match(html,new RegExp(`id="${id}"`));
assert.match(html,/STORY_QUESTION_DEFAULTS074/);
assert.match(html,/storyQuestions074\[mode\]\.splice\(idx,1\)/);
assert.match(html,/storyQuestions074\[mode\]\.push\('새 질문'\)/);
assert.match(html,/기본 설정으로 되돌리시겠습니까/);
assert.match(html,/state\.storyQuestions074\[mode\]=\[\.\.\.STORY_QUESTION_DEFAULTS074\[mode\]\]/);
assert.match(html,/storyTemplateFor074\(mode\)/);

// Grok 4.3 and Gemini free/paid safety labels.
assert.match(html,/'grok-4\.3':\{input:1\.25,cached:\.20,output:2\.50\}/);
assert.match(html,/id="geminiHidePaid074"/);
for(const tier of ['free','paid','limited','unknown']) assert.match(html,new RegExp(`'${tier}'`));
assert.match(html,/무료 티어/);
assert.match(html,/유료 전용/);
assert.match(html,/프로젝트 제한 가능/);
assert.match(html,/provider!=='gemini'\|\|!state\.geminiHidePaid074\|\|geminiTier074\(id\)!=='paid'/);
assert.match(html,/'gemini-2\.5-computer-use-preview-10-2025':'free'/);

// Build 074 must remain a normal accumulated public release.
assert.match(workflow,/GH_TOKEN: \$\{\{ secrets\.RELEASE_TOKEN \}\}/);
assert.match(workflow,/GH_REPO: yhj4735-gif\/NAI-Fold-Releases/);
assert.match(workflow,/TAG="\$BUILD3"/);
assert.match(workflow,/NAI-Fold-Studio-1\.00-Build\$\{BUILD3\}\.apk/);
assert.match(workflow,/BUILD3|CHANGELOG/);
assert.doesNotMatch(workflow,/--prerelease/);

console.log('device-regressions-074: requested 074 changes passed');
