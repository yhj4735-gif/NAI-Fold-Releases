import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';

const rust=fs.readFileSync(new URL('../src-tauri/src/lib.rs',import.meta.url),'utf8');
const html=fs.readFileSync(new URL('../frontend/index.html',import.meta.url),'utf8');
const build=fs.readFileSync(new URL('../build.yml',import.meta.url),'utf8');
const config=JSON.parse(fs.readFileSync(new URL('../src-tauri/tauri.conf.json',import.meta.url),'utf8'));
const key=fs.readFileSync(new URL('../ci/android-debug.keystore',import.meta.url));

assert.equal(config.identifier,'com.naifold.studio');
assert.equal(config.version,'1.0.0');
assert.equal(config.bundle.android.versionCode,2099000054);
assert.equal(crypto.createHash('sha256').update(key).digest('hex'),'d98486c90903842258548b7a36dd23ad0aeca42c28ba8c64200bba408b1afa1a');
assert.match(build,/PINNED_KEYSTORE_SHA256="d98486c90903842258548b7a36dd23ad0aeca42c28ba8c64200bba408b1afa1a"/);
assert.match(build,/PINNED_CERT_SHA256=/);
assert.match(build,/test \"\$ACTUAL_KEYSTORE_SHA256\" = \"\$PINNED_KEYSTORE_SHA256\"/);
assert.match(rust,/chat\/completions/);
assert.match(rust,/choices/);
assert.match(rust,/extract_choice_text/);
assert.match(rust,/parse_sse_body/);
assert.match(rust,/\"_naifold_text\": text/);
assert.match(rust,/NovelAI Text 054/);
assert.match(html,/response\?\._naifold_text/);
assert.match(html,/NovelAI Text 054/);
console.log('device-regressions-054: canonical NovelAI parser and permanent Android update-signing guard passed');
