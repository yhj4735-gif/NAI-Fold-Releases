import assert from 'node:assert/strict';
import fs from 'node:fs';

const html=fs.readFileSync(new URL('../frontend/index.html',import.meta.url),'utf8');
const rust=fs.readFileSync(new URL('../src-tauri/src/lib.rs',import.meta.url),'utf8');
const config=JSON.parse(fs.readFileSync(new URL('../src-tauri/tauri.conf.json',import.meta.url),'utf8'));

assert.equal(config.identifier,'com.naifold.studio');
assert.ok(config.bundle.android.versionCode>=2099000051);
assert.doesNotMatch(html,/data-tool="Edit" aria-label="편집"/);
assert.match(html,/data-settings-tab="help">Feature Guide/);
assert.match(html,/data-settings-pane="help"/);
assert.match(html,/advanced-backup050/);
assert.match(html,/id="addWildcardPack"/);
assert.match(html,/'치마':'skirt'/);
assert.match(html,/story-concept050/);
assert.match(html,/choice\?\.text,[\s\S]*choice\?\.parsedContent,[\s\S]*choice\?\.message\?\.content/);
assert.match(html,/topLevelKeys/);
assert.match(html,/\.home-history-list\{[\s\S]*overflow-y:auto!important/);
assert.match(rust,/extract_choice_text/);
console.log('device-regressions-050: bounded history, HELP guide, focused Story parser and expanded Korean wildcard flow passed');
