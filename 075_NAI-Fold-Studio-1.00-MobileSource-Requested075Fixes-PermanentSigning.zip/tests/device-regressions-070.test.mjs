import fs from 'node:fs';
import assert from 'node:assert/strict';

const html=fs.readFileSync(new URL('../frontend/index.html',import.meta.url),'utf8');
const rust=fs.readFileSync(new URL('../src-tauri/src/lib.rs',import.meta.url),'utf8');
const conf=JSON.parse(fs.readFileSync(new URL('../src-tauri/tauri.conf.json',import.meta.url),'utf8'));

assert.equal(conf.version,'1.0.0');
assert.equal(conf.identifier,'com.naifold.studio');
assert.ok(conf.bundle.android.versionCode>=2099000075);

// Header: real NovelAI subscription data + external AI usage card + persistent LOCAL collapse.
assert.match(html,/id="naiAnlas070"/);
assert.match(html,/id="naiBattery070"/);
assert.ok(/id="topAiUsage070"/.test(html)||/id="apiMonthUsage071"/.test(html),"external AI usage must remain accessible");
assert.match(html,/refreshNovelAiUsage070\(\{quiet:true\}\)/);
assert.match(html,/runtimeSubscription=await nativeInvoke\('check_subscription',\{token:stored\}\);\s*renderNovelAiUsage070\(\)/);
assert.match(html,/trainingStepsLeft\.fixedTrainingStepsLeft/);
assert.match(html,/trainingStepsLeft\.purchasedTrainingSteps/);
assert.match(html,/usage\.percent/);
assert.match(html,/id='localToggle070'|id="localToggle070"|tag\.id='localToggle070'/);
assert.match(html,/top-info-collapsed070/);
assert.match(html,/body\.top-info-collapsed070 \.topbar-meta,body\.top-info-collapsed070 \.top-actions\{display:none!important\}/);
assert.match(html,/state\.topInfoCollapsed070/);

// OpenAI / Gemini / Grok: model discovery, model testing, per-model status and usage/cost tracking.
assert.match(rust,/async fn list_external_ai_models/);
assert.match(rust,/async fn test_external_ai_model/);
assert.match(rust,/OPENAI_API\}\/v1\/models/);
assert.match(rust,/XAI_API\}\/v1\/models/);
assert.match(rust,/GEMINI_API\}\/v1beta\/models/);
assert.match(rust,/normalized_external_usage/);
for(const provider of ['openai','gemini','grok']) assert.match(html,new RegExp(`externalAiModels\\?\\.\\[provider\\]|${provider}`));
assert.match(html,/externalAiModelCatalog070/);
assert.match(html,/externalAiModelStatus070/);
assert.match(html,/✓ 사용 가능/);
assert.match(html,/🔒 결제\/권한/);
assert.match(html,/⚠ (?:호출 )?한도 초과/);
assert.match(html,/이번 요청/);
assert.match(html,/이번 달/);
assert.match(html,/예상 비용/);
assert.match(html,/recordExternalUsage070/);

// Story: large answer zone at the bottom and explicit Android/Fold bottom safe space.
assert.match(html,/#panel-ai \.chat-log\{order:50!important/);
assert.match(html,/#panel-ai \.chat-input\{order:51!important/);
assert.match(html,/height:clamp\(420px,62dvh,780px\)!important/);
assert.match(html,/@media\(pointer:coarse\)\{#panel-ai \.panel-body\{padding-bottom:calc\(max\(26px,var\(--safe-bottom,0px\)\) \+ 68px\)!important/);
assert.match(html,/function updateStoryBottomSpace067\([^)]*\)\{[^}]*0px/);

// Generation: button stays fixed and only refresh glyph gets the final 070 animation override.
assert.match(html,/#generateBtn\.generating \.gen-spinner068\{visibility:visible!important;animation:spin070 \.76s linear infinite!important\}/);
assert.match(html,/@keyframes spin070\{from\{transform:rotate\(0deg\)\}to\{transform:rotate\(360deg\)\}\}/);
const authority070=html.match(/<style id="authority070">([\s\S]*?)<\/style>/)?.[1]||'';
assert.doesNotMatch(authority070,/#generateBtn \.gen-spinner068\{[^}]*transform:none!important/);

// Deep wildcard/Danbooru semantic layer + Korean reverse-search.
assert.match(html,/gangbang:'집단 성행위'/);
assert.match(html,/'집단 성행위':'gangbang'/);
assert.match(html,/KO_PHRASE_048\[raw\]/);
assert.match(html,/KO_WORD_048\[word\]/);
assert.match(html,/Object\.keys\(KO_PHRASE_048\)/);
assert.match(html,/tagTranslationCacheSchema070/);

// Tool-specific UI: Inpaint-only blocks are force-hidden outside Inpaint; Upscale hides strength/noise.
assert.match(authority070,/\.inpaint-prompt069\[hidden\],\.inpaint-mask-controls069\[hidden\],#inpaintPromptField069\[hidden\]\{display:none!important\}/);
assert.match(html,/const inpaint=tool==='Inpaint',upscale=tool==='Upscale'/);
assert.match(html,/imageToolStrength049'\)\.closest\('\.field'\)\.style\.display=upscale\?'none':''/);
assert.match(html,/\$\('inpaintPrompt069'\)\.hidden=!inpaint/);

// Fullscreen viewer shares the selected history item and can toggle favorite.
assert.match(html,/id="mainImageViewerFavorite070"/);
assert.match(html,/function syncMainImageViewerFavorite070/);
assert.match(html,/item\.favorite=!item\.favorite/);
assert.match(html,/renderGalleryHistory069\(true\)/);

// History delete controls are closed by default and one-line/compact only after Delete is pressed.
assert.match(html,/id="galleryDeleteToolbar069" hidden/);
assert.match(authority070,/#galleryDeleteToolbar069\[hidden\]\{display:none!important\}/);
assert.match(authority070,/#galleryDeleteToolbar069\{display:flex!important;flex-wrap:nowrap!important/);
assert.match(html,/toolbar\.hidden=!historyDeleteMode069/);
assert.match(html,/historyDeleteMode069=!historyDeleteMode069/);

// 069 non-destructive history, incremental history and corrected upscale remain intact.
assert.match(html,/const HISTORY_PAGE_SIZE070=30/);
assert.match(html,/id="galleryHistoryPagination070"/);
assert.match(html,/data-history-page070/);
assert.match(html,/historyPageCount070/);
assert.match(html,/items\.slice\(start,start\+HISTORY_PAGE_SIZE070\)/);
assert.match(html,/state\.history\.unshift\(entry\)/);
assert.match(rust,/zip::ZipArchive::new/);
assert.match(rust,/fn sniff_image_mime/);
assert.match(rust,/\{CORE_API\}\/ai\/upscale/);

console.log('device-regressions-070: requested follow-up passed');
