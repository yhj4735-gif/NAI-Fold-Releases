import assert from 'node:assert/strict';
import fs from 'node:fs';

const html = fs.readFileSync(new URL('../frontend/index.html', import.meta.url), 'utf8');
const rust = fs.readFileSync(new URL('../src-tauri/src/lib.rs', import.meta.url), 'utf8');

assert.match(html, /@media\(min-width:481px\) and \(max-width:900px\)/);
assert.match(html, /grid-template-columns:minmax\(176px,196px\) minmax\(284px,1fr\) 72px!important/);
assert.match(html, /inset:calc\(var\(--safe-top,0px\) \+ var\(--usable-head042\)\) 0 0 0!important/);
assert.match(html, /\.panel\.open>\.panel-body\{padding-bottom:calc\(var\(--safe-bottom,0px\) \+ 12px\)!important/);
assert.match(html, /\.diary-rail\{[\s\S]*?position:fixed!important;z-index:900!important/);
assert.match(html, /\.modal\.show:not\(#comicModal\.diary-comic-page\)\{[\s\S]*?position:fixed!important;z-index:700!important/);
assert.match(html, /tauriDialogSave\([\s\S]*?Pictures 또는 DCIM에 합성 이미지 저장/);
assert.match(html, /plugin:fs\|write_file/);
assert.doesNotMatch(html, /이미지가 저장되었습니다 · 기기 저장\/공유 완료/);
assert.doesNotMatch(rust, /"clio-v1"/);
assert.match(rust, /\/oa\/v1\/chat\/completions/);
assert.doesNotMatch(rust, /for fallback in/);
assert.match(html, /data-dragging="true"/);
assert.match(html, /if\(type==='OPEN'\|\|type==='CLOSE'\)/);
assert.doesNotMatch(fs.readFileSync(new URL('../frontend/bookmark-controller.js', import.meta.url), 'utf8'), /return 'TOGGLE';/);

console.log('device-regressions-043: header, safe-area, tabs, modal, gallery save, OA story route and bookmark slide assertions passed');
