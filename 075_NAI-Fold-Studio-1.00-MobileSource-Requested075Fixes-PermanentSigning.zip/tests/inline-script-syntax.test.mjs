import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';

const html = fs.readFileSync(new URL('../frontend/index.html', import.meta.url), 'utf8');
const scripts = [...html.matchAll(/<script([^>]*)>([\s\S]*?)<\/script>/gi)]
  .filter(match => !/\bsrc\s*=/.test(match[1]) && !/application\/(?:json|ld\+json)/i.test(match[1]));

assert.ok(scripts.length > 0, 'no inline scripts found');
scripts.forEach((match, index) => new vm.Script(match[2], { filename: `index-inline-${index + 1}.js` }));

console.log(`inline-script-syntax: ${scripts.length} inline scripts compiled`);
