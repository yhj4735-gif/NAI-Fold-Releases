import assert from 'node:assert/strict';
import fs from 'node:fs';

const html=fs.readFileSync(new URL('../frontend/index.html',import.meta.url),'utf8');
const rust=fs.readFileSync(new URL('../src-tauri/src/lib.rs',import.meta.url),'utf8');
const tauri=JSON.parse(fs.readFileSync(new URL('../src-tauri/tauri.conf.json',import.meta.url),'utf8'));

assert.match(html,/nai-fold-symbol-047-white\.png/);
assert.doesNotMatch(html,/class="brand-logo-img" src="assets034\/user-logo-exact\.png"/);
assert.match(html,/#comicHistorySourceModal \.source-history-thumb img\{[\s\S]*?object-fit:cover!important/);
assert.match(html,/grid-template-columns:repeat\(auto-fill,minmax\(106px,1fr\)\)!important/);
assert.match(html,/body \.diary-rail,body\.panel-active \.diary-rail\{z-index:1900!important/);
assert.match(html,/body\.android-runtime \.panel\.open,body\.real-android \.panel\.open/);
assert.match(html,/body\.panel-active \.app::after\{[\s\S]*?background:var\(--panel-surface044\)!important/);
assert.match(html,/--bookmark-closed-peek041:54px/);
assert.match(html,/--bookmark-open-gap044:104px/);
assert.match(html,/storyModelSelect/);
assert.match(rust,/\/oa\/v1\/chat\/completions/);
assert.doesNotMatch(rust,/"clio-v1"/);
assert.doesNotMatch(rust,/"kayra-v1"/);
assert.equal(tauri.version,'1.0.0');
assert.ok(tauri.bundle.android.versionCode>=2099000051);

const symbol=fs.readFileSync(new URL('../frontend/assets034/nai-fold-symbol-047-white.png',import.meta.url));
assert.equal(symbol.subarray(1,4).toString('ascii'),'PNG');
for(const icon of ['32x32.png','128x128.png','128x128@2x.png','icon.png']){
  const bytes=fs.readFileSync(new URL(`../src-tauri/icons/${icon}`,import.meta.url));
  assert.equal(bytes.subarray(1,4).toString('ascii'),'PNG',`${icon}: not PNG`);
  assert.equal(bytes[25],6,`${icon}: PNG must be RGBA`);
}

console.log('device-regressions-044: compact history, persistent pins, unified panels, current story models, crisp RGBA icon and bookmark geometry passed');
