import fs from 'node:fs';
import assert from 'node:assert/strict';

const html=fs.readFileSync(new URL('../frontend/index.html',import.meta.url),'utf8');
const rust=fs.readFileSync(new URL('../src-tauri/src/lib.rs',import.meta.url),'utf8');
const conf=JSON.parse(fs.readFileSync(new URL('../src-tauri/tauri.conf.json',import.meta.url),'utf8'));
const workflow=fs.readFileSync(new URL('../build.yml',import.meta.url),'utf8');
const channel=JSON.parse(fs.readFileSync(new URL('../frontend/release-channel.json',import.meta.url),'utf8'));
const history=JSON.parse(fs.readFileSync(new URL('../frontend/changelog.json',import.meta.url),'utf8'));

assert.equal(conf.version,'1.0.0');
assert.equal(conf.identifier,'com.naifold.studio');
assert.ok(conf.bundle.android.versionCode>=2099000075);
assert.equal(channel.repository,'yhj4735-gif/NAI-Fold-Releases');
assert.equal(channel.tag,'latest');
assert.ok(channel.build>=74);
assert.ok(history.currentBuild>=74);
assert.ok((history.releases[0]?.build||0)>=74);

// One-shot AI helper: no room/history/context transmission.
for(const id of ['storyRoomBar072','storyRoomSelect072','storyNewRoom072','storyDeleteRoom072','clearChatBtn']) assert.doesNotMatch(html,new RegExp(`id="${id}"`));
assert.doesNotMatch(html,/<option value="generalchat">/);
assert.match(html,/<option value="persona">페르소나 모드<\/option>/);
assert.doesNotMatch(html,/STORY_ROOMS_KEY072/);
assert.doesNotMatch(html,/buildStoryConversationContext072/);
assert.match(html,/function renderStoryOneShot073/);
assert.match(html,/composeStoryPayload075\(text\)/);
assert.match(html,/이전 요청·응답은 다음 (?:API 요청에 포함|요청에 문맥으로 사용)하지 않습니다/);

// External model selector is app-owned and must not invoke Android keyboard.
for(const id of ['externalAiModel055','openAiModel055','geminiModel055','grokModel055']){
  const tag=html.match(new RegExp(`<input[^>]+id="${id}"[^>]*>`))?.[0]||'';
  assert.match(tag,/readonly/);
  assert.match(tag,/inputmode="none"/);
}
assert.match(html,/input\.addEventListener\('pointerdown',e=>\{e\.preventDefault\(\);input\.blur\(\);openModelPicker071\(input\)\}\)/);
assert.doesNotMatch(html,/closeModelPicker071\(\);input\.focus\(\)/);

// 21:9 portrait request-specific authority applies only to compact 21:9.
const a=html.match(/<style id="authority073">([\s\S]*?)<\/style>/)?.[1]||'';
assert.ok(a.length>1500,'missing 073 authority');
assert.match(a,/body\.layout-compact072\.diary-portrait\.ratio-21-9/);
assert.match(a,/#panel-workspace \.panel-body\.workspace-body032\{display:flex!important;flex-direction:column!important/);
assert.match(a,/#comicModal\.diary-comic-page\{right:0!important;padding-right:var\(--rail-safe073\)!important/);
assert.match(a,/\.top-meta-cluster\{width:max-content!important/);
assert.match(a,/\.home-workspace\{grid-template-rows:clamp\(230px,34dvh,340px\) 36px 72px 34px!important/);
assert.match(a,/\.main-image-save068\{position:static!important/);

// Public accumulated release channel + previous versions UI.
assert.match(workflow,/GH_TOKEN: \$\{\{ secrets\.RELEASE_TOKEN \}\}/);
assert.match(workflow,/GH_REPO: yhj4735-gif\/NAI-Fold-Releases/);
assert.match(workflow,/TAG="\$BUILD3"/);
assert.match(workflow,/gh release create[\s\S]{0,180}"\$TAG"[\s\S]{0,180}--target main/);
assert.doesNotMatch(workflow,/gh release view latest-build/);
assert.doesNotMatch(workflow,/--prerelease/);
assert.match(workflow,/NAI-Fold-Studio-1\.00-Build\$\{BUILD3\}\.apk/);
assert.match(rust,/releases\/latest/);
assert.match(rust,/async fn fetch_github_releases/);
assert.match(html,/id="versionPrevious073"/);
assert.match(html,/nativeInvoke\('fetch_github_releases'/);

console.log('device-regressions-073: requested-only one-shot, selector, 21:9 and public release changes passed');
